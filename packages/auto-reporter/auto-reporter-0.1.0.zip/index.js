const EOG_STATS_PATH = '/lol-end-of-game/v1/eog-stats-block';
const GAMEFLOW_SESSION_PATH = '/lol-gameflow/v1/session';
const LOBBY_PATH = '/lol-lobby/v2/lobby';
const CURRENT_SUMMONER_PATH = '/lol-summoner/v1/current-summoner';
const MATCH_HISTORY_CURRENT_SUMMONER_PATH = '/lol-match-history/v1/products/lol/current-summoner/matches';
const MATCH_HISTORY_GAME_PATH = '/lol-match-history/v1/games';
const REPORT_PATH = '/lol-player-report-sender/v1/end-of-game-reports';
const MATCH_HISTORY_REPORT_PATH = '/lol-player-report-sender/v1/match-history-reports';
const REPORTED_PLAYERS_PATH = '/lol-player-report-sender/v1/reported-players/gameId';

const PANEL_ID = 'lpl-auto-reporter-panel';

const REPORT_CATEGORIES = [
  {
    key: 'verbalAbuse',
    value: 'VERBAL_ABUSE',
    label: 'Verbal abuse',
    description: 'Report abusive or harassing chat.',
    default: false,
  },
  {
    key: 'negativeAttitude',
    value: 'NEGATIVE_ATTITUDE',
    label: 'Negative attitude',
    description: 'Report griefing through toxic behavior or refusal to cooperate.',
    default: false,
  },
  {
    key: 'intentionalFeeding',
    value: 'ASSISTING_ENEMY_TEAM',
    label: 'Intentional feeding',
    description: 'Report intentional deaths or deliberate game sabotage.',
    default: false,
  },
  {
    key: 'leavingAfk',
    value: 'LEAVING_AFK',
    label: 'Leaving or AFK',
    description: 'Report leaving the game or being AFK.',
    default: false,
  },
  {
    key: 'hateSpeech',
    value: 'HATE_SPEECH',
    label: 'Hate speech',
    description: 'Report identity-based harassment.',
    default: false,
  },
  {
    key: 'cheating',
    value: 'THIRD_PARTY_TOOLS',
    label: 'Cheating',
    description: 'Report scripting, botting, or third-party tool abuse.',
    default: false,
  },
  {
    key: 'offensiveName',
    value: 'INAPPROPRIATE_NAME',
    label: 'Offensive name',
    description: 'Report an offensive Riot ID or summoner name.',
    default: false,
  },
];

let currentLpl = null;
let currentSummoner = null;
let currentEogStats = null;
let settingsState = {
  includeRandomTeammates: true,
  showLastGamePreview: false,
  reportComment: '',
};
let reportInFlight = false;
let lastStatus = 'Waiting for end-game stats.';
let reportedCache = new Set();
let partyPuuids = new Set();
let partySummonerIds = new Set();
let partySnapshotCaptured = false;
let previewModeActive = false;
let selectedPreviewPuuids = new Set();
let cleanupFns = [];

const sleep = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

const formatError = (error) => {
  if (!error) return 'unknown error';
  if (typeof error === 'string') return error;
  if (error.body) return `${error.message || 'request failed'} (${error.body})`;
  return error.message || String(error);
};

const escapeHtml = (value) =>
  String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

const playerName = (player) => {
  const gameName = String(player?.riotIdGameName || '').trim();
  const tagLine = String(player?.riotIdTagLine || '').trim();
  if (gameName && tagLine) return `${gameName}#${tagLine}`;
  if (gameName) return gameName;
  return String(player?.summonerName || player?.puuid || 'Unknown player');
};

const normalizePuuid = (value) => String(value || '').trim().toLowerCase();

const normalizeSummonerId = (value) => {
  const id = Number(value || 0);
  return Number.isFinite(id) && id > 0 ? String(id) : '';
};

const normalizeEogStats = (payload) => {
  const stats = payload?.data ?? payload;
  if (!stats || typeof stats !== 'object') return null;
  if (!Array.isArray(stats.teams)) return null;
  return stats;
};

const getGameId = (stats) => {
  const value = stats?.reportGameId ?? stats?.gameId ?? stats?.localPlayer?.gameId;
  const id = Number(value || 0);
  return Number.isFinite(id) && id > 0 ? id : 0;
};

const isPreviewStats = (stats) => Boolean(stats?.__lplPreviewMode);

const getSelectedCategories = () =>
  REPORT_CATEGORIES
    .filter((category) => Boolean(settingsState[category.key]))
    .map((category) => category.value);

const findLocalTeam = (stats) => {
  const localPuuid = String(
    stats?.localPlayer?.puuid || currentSummoner?.puuid || '',
  ).toLowerCase();
  const teams = Array.isArray(stats?.teams) ? stats.teams : [];

  return (
    teams.find((team) => team?.isPlayerTeam) ||
    teams.find((team) =>
      Array.isArray(team?.players) &&
      team.players.some(
        (player) =>
          player?.isLocalPlayer ||
          (localPuuid && String(player?.puuid || '').toLowerCase() === localPuuid),
      ),
    ) ||
    null
  );
};

const isPartyMember = (player) => {
  const puuid = normalizePuuid(player?.puuid);
  const summonerId = normalizeSummonerId(player?.summonerId);
  return (
    (puuid && partyPuuids.has(puuid)) ||
    (summonerId && partySummonerIds.has(summonerId))
  );
};

const collectReportablePlayers = (stats) => {
  const teams = Array.isArray(stats?.teams) ? stats.teams : [];
  const localTeam = findLocalTeam(stats);
  const localTeamId = Number(localTeam?.teamId ?? stats?.localPlayer?.teamId ?? 0);
  const localPuuid = String(
    stats?.localPlayer?.puuid || currentSummoner?.puuid || '',
  ).toLowerCase();

  const players = [];
  for (const team of teams) {
    const sameTeam =
      team === localTeam ||
      team?.isPlayerTeam ||
      (localTeamId && Number(team?.teamId || 0) === localTeamId);

    if (sameTeam && !settingsState.includeRandomTeammates) continue;
    if (sameTeam && !partySnapshotCaptured) continue;

    for (const player of Array.isArray(team?.players) ? team.players : []) {
      const puuid = String(player?.puuid || '').trim();
      if (!puuid) continue;
      if (player?.botPlayer) continue;
      if (player?.isLocalPlayer) continue;
      if (localPuuid && puuid.toLowerCase() === localPuuid) continue;
      if (sameTeam && isPartyMember(player)) continue;
      players.push(player);
    }
  }

  return players;
};

const reportKey = (gameId, puuid) => `${gameId}:${String(puuid || '').toLowerCase()}`;

const buildReportPayload = (gameId, player, categories, { includeObfuscated = false } = {}) => {
  const payload = {
    comment: String(settingsState.reportComment || ''),
    gameId,
    categories,
    offenderSummonerId: Number(player?.summonerId || 0),
    offenderPuuid: String(player?.puuid || ''),
  };

  if (!Number.isFinite(payload.offenderSummonerId) || payload.offenderSummonerId <= 0) {
    delete payload.offenderSummonerId;
  }

  if (includeObfuscated && player?.obfuscatedPuuid) {
    payload.obfuscatedOffenderPuuid = String(player.obfuscatedPuuid);
  }

  return payload;
};

const stringifyLogValue = (value) => {
  if (value == null) return '';
  if (typeof value === 'string') return value;
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
};

const shouldLogReportRequest = (url) => {
  const value = String(url || '');
  return (
    value.includes('/lol-player-report-sender/') ||
    value.includes('/player-reporting/')
  );
};

function installReportRequestLogger(lpl) {
  const originalFetch = window.fetch;
  const OriginalXMLHttpRequest = window.XMLHttpRequest;

  if (typeof originalFetch === 'function') {
    window.fetch = async function lplReportLoggerFetch(input, init = {}) {
      const url = typeof input === 'string' ? input : input?.url;
      const method = String(init?.method || input?.method || 'GET').toUpperCase();
      const body = init?.body;
      const shouldLog = shouldLogReportRequest(url);

      if (shouldLog) {
        lpl.log.info(`[report-sniffer] fetch -> ${method} ${url} body=${stringifyLogValue(body)}`);
      }

      const response = await originalFetch.apply(this, arguments);

      if (shouldLog) {
        try {
          const text = await response.clone().text();
          lpl.log.info(
            `[report-sniffer] fetch <- ${method} ${url} status=${response.status} body=${text.slice(0, 1200)}`,
          );
        } catch (error) {
          lpl.log.warn(`[report-sniffer] fetch response read failed: ${formatError(error)}`);
        }
      }

      return response;
    };
  }

  if (typeof OriginalXMLHttpRequest === 'function') {
    window.XMLHttpRequest = function lplReportLoggerXMLHttpRequest() {
      const xhr = new OriginalXMLHttpRequest();
      let requestMethod = 'GET';
      let requestUrl = '';
      let requestShouldLog = false;

      const originalOpen = xhr.open;
      const originalSend = xhr.send;

      xhr.open = function lplReportLoggerOpen(method, url) {
        requestMethod = String(method || 'GET').toUpperCase();
        requestUrl = String(url || '');
        requestShouldLog = shouldLogReportRequest(requestUrl);
        return originalOpen.apply(xhr, arguments);
      };

      xhr.send = function lplReportLoggerSend(body) {
        if (requestShouldLog) {
          lpl.log.info(
            `[report-sniffer] xhr -> ${requestMethod} ${requestUrl} body=${stringifyLogValue(body)}`,
          );
          xhr.addEventListener('loadend', () => {
            let response = '';
            try {
              response = String(xhr.responseText || '');
            } catch {}
            lpl.log.info(
              `[report-sniffer] xhr <- ${requestMethod} ${requestUrl} status=${xhr.status} body=${response.slice(0, 1200)}`,
            );
          });
        }
        return originalSend.apply(xhr, arguments);
      };

      return xhr;
    };
    window.XMLHttpRequest.prototype = OriginalXMLHttpRequest.prototype;
  }

  lpl.log.info('[report-sniffer] installed');

  return () => {
    if (typeof originalFetch === 'function') {
      window.fetch = originalFetch;
    }
    if (typeof OriginalXMLHttpRequest === 'function') {
      window.XMLHttpRequest = OriginalXMLHttpRequest;
    }
    lpl.log.info('[report-sniffer] removed');
  };
}

async function loadCurrentSummoner() {
  if (!currentLpl) return null;
  try {
    currentSummoner = await currentLpl.league.lcuRequest('GET', CURRENT_SUMMONER_PATH);
  } catch (error) {
    currentLpl.log.warn(`current summoner lookup failed: ${formatError(error)}`);
  }
  return currentSummoner;
}

async function persistPartySnapshot() {
  if (!currentLpl) return;
  try {
    await currentLpl.storage.set('lastPartySnapshot', {
      capturedAt: Date.now(),
      puuids: Array.from(partyPuuids),
      summonerIds: Array.from(partySummonerIds),
    });
  } catch (error) {
    currentLpl.log.warn(`party snapshot save failed: ${formatError(error)}`);
  }
}

async function restorePartySnapshot() {
  if (!currentLpl) return;
  try {
    const snapshot = await currentLpl.storage.get('lastPartySnapshot', null);
    if (!snapshot || typeof snapshot !== 'object') return;

    const ageMs = Date.now() - Number(snapshot.capturedAt || 0);
    if (!Number.isFinite(ageMs) || ageMs > 8 * 60 * 60 * 1000) return;

    partyPuuids = new Set(
      (Array.isArray(snapshot.puuids) ? snapshot.puuids : [])
        .map(normalizePuuid)
        .filter(Boolean),
    );
    partySummonerIds = new Set(
      (Array.isArray(snapshot.summonerIds) ? snapshot.summonerIds : [])
        .map(normalizeSummonerId)
        .filter(Boolean),
    );
    partySnapshotCaptured = partyPuuids.size > 0 || partySummonerIds.size > 0;
  } catch (error) {
    currentLpl.log.warn(`party snapshot restore failed: ${formatError(error)}`);
  }
}

async function capturePartySnapshot(payload, reason) {
  if (!currentLpl) return;
  const lobby = payload?.data ?? payload;
  const members = Array.isArray(lobby?.members) ? lobby.members : [];
  if (!members.length) return;

  partyPuuids = new Set(
    members
      .map((member) => normalizePuuid(member?.puuid))
      .filter(Boolean),
  );
  partySummonerIds = new Set(
    members
      .map((member) => normalizeSummonerId(member?.summonerId))
      .filter(Boolean),
  );
  partySnapshotCaptured = partyPuuids.size > 0 || partySummonerIds.size > 0;
  await persistPartySnapshot();

  currentLpl.log.info(
    `captured party snapshot via ${reason}: ${partyPuuids.size || partySummonerIds.size} member(s)`,
  );
}

async function refreshPartySnapshot(reason) {
  if (!currentLpl) return;
  try {
    await capturePartySnapshot(
      await currentLpl.league.lcuRequest('GET', LOBBY_PATH),
      reason,
    );
  } catch (error) {
    if (error?.status !== 404) {
      currentLpl.log.warn(`party snapshot lookup failed via ${reason}: ${formatError(error)}`);
    }
  }
}

const getMatchHistoryGames = (payload) => {
  if (Array.isArray(payload?.games?.games)) return payload.games.games;
  if (Array.isArray(payload?.games)) return payload.games;
  return [];
};

const normalizeMatchHistoryGame = (game) => {
  if (!game || typeof game !== 'object') return null;

  const participants = Array.isArray(game.participants) ? game.participants : [];
  const identities = new Map(
    (Array.isArray(game.participantIdentities) ? game.participantIdentities : [])
      .map((identity) => [Number(identity?.participantId || 0), identity?.player || {}]),
  );
  const gameId = Number(game.gameId || 0);
  const localPuuid = normalizePuuid(currentSummoner?.puuid);
  const localSummonerId = normalizeSummonerId(currentSummoner?.summonerId);

  const players = participants
    .map((participant) => {
      const participantId = Number(participant?.participantId || 0);
      const identity = identities.get(participantId) || {};
      const puuid = normalizePuuid(identity.puuid) || `lpl-history-${gameId}-${participantId}`;
      const summonerId = normalizeSummonerId(identity.summonerId);
      const championId = Number(participant?.championId || 0);
      const displayName =
        identity.gameName ||
        identity.summonerName ||
        (participantId ? `Player ${participantId}` : 'Unknown player');
      const isLocalPlayer =
        (localPuuid && puuid === localPuuid) ||
        (localSummonerId && summonerId === localSummonerId);

      return {
        puuid,
        summonerId: Number(summonerId || 0),
        riotIdGameName: displayName,
        riotIdTagLine: identity.tagLine || '',
        summonerName: identity.summonerName || displayName,
        championName:
          participant?.championName ||
          participant?.championNameAlias ||
          (championId ? `Champion ${championId}` : 'Player'),
        teamId: Number(participant?.teamId || 0),
        isLocalPlayer,
      };
    })
    .filter((player) => player.teamId);

  const localPlayer = players.find((player) => player.isLocalPlayer);
  if (!gameId || !players.length || !localPlayer) return null;

  const teamIds = Array.from(
    new Set([
      ...(Array.isArray(game.teams) ? game.teams.map((team) => Number(team?.teamId || 0)) : []),
      ...players.map((player) => Number(player.teamId || 0)),
    ]),
  ).filter(Boolean);

  return {
    __lplPreviewMode: true,
    previewLabel: 'Last game',
    gameId,
    reportGameId: gameId,
    localPlayer,
    gameMode: game.gameMode || '',
    queueId: game.queueId || 0,
    gameCreationDate: game.gameCreationDate || '',
    teams: teamIds.map((teamId) => ({
      teamId,
      isPlayerTeam: teamId === Number(localPlayer.teamId || 0),
      players: players.filter((player) => Number(player.teamId || 0) === teamId),
    })),
  };
};

async function buildLastGamePreviewStats() {
  if (!currentLpl) return null;

  await loadCurrentSummoner();

  const history = await currentLpl.league.lcuRequest(
    'GET',
    `${MATCH_HISTORY_CURRENT_SUMMONER_PATH}?begIndex=0&endIndex=1`,
  );
  const latest = getMatchHistoryGames(history)[0];
  const gameId = Number(latest?.gameId || 0);
  if (!gameId) return null;

  let detail = latest;
  try {
    detail = await currentLpl.league.lcuRequest('GET', `${MATCH_HISTORY_GAME_PATH}/${gameId}`);
  } catch (error) {
    currentLpl.log.warn(`last game detail lookup failed, using match list row: ${formatError(error)}`);
  }

  return normalizeMatchHistoryGame(detail);
}

async function refreshLastGamePreview(reason) {
  if (!settingsState.showLastGamePreview) {
    if (previewModeActive) {
      currentEogStats = null;
      previewModeActive = false;
      selectedPreviewPuuids = new Set();
      lastStatus = 'Waiting for end-game stats.';
      renderPanel();
    }
    return;
  }

  try {
    const stats = await buildLastGamePreviewStats();
    if (!stats) {
      lastStatus = 'No previous match found in match history.';
      renderPanel();
      return;
    }

    currentEogStats = stats;
    previewModeActive = true;
    const gameId = getGameId(stats);
    await refreshReportedCache(gameId);
    const targets = collectReportablePlayers(stats).filter(
      (player) => !reportedCache.has(reportKey(gameId, player.puuid)),
    );
    selectedPreviewPuuids = new Set(
      targets.map((player) => normalizePuuid(player.puuid)).filter(Boolean),
    );
    lastStatus = `Last game preview via ${reason}: ${targets.length} player${targets.length === 1 ? '' : 's'} selected.`;
    currentLpl?.log.info(lastStatus);
    renderPanel();
  } catch (error) {
    lastStatus = `Last game preview failed: ${formatError(error)}`;
    currentLpl?.log.warn(lastStatus);
    renderPanel();
  }
}

async function refreshReportedCache(gameId) {
  if (!currentLpl || !gameId) return reportedCache;
  try {
    const reported = await currentLpl.league.lcuRequest(
      'GET',
      `${REPORTED_PLAYERS_PATH}/${encodeURIComponent(String(gameId))}`,
    );
    const next = new Set(reportedCache);
    for (const item of Array.isArray(reported) ? reported : []) {
      const puuid =
        item?.offenderPuuid ||
        item?.reportedPuuid ||
        item?.puuid ||
        item?.playerPuuid ||
        item;
      if (typeof puuid === 'string' && puuid) {
        next.add(reportKey(gameId, puuid));
      }
    }
    reportedCache = next;
  } catch (error) {
    if (error?.status !== 404) {
      currentLpl.log.warn(`reported-player lookup failed: ${formatError(error)}`);
    }
  }
  return reportedCache;
}

async function loadEogStats(reason) {
  if (!currentLpl) return null;
  try {
    const stats = normalizeEogStats(await currentLpl.league.lcuRequest('GET', EOG_STATS_PATH));
    if (!stats) return null;

    currentEogStats = stats;
    selectedPreviewPuuids = new Set();
    await loadCurrentSummoner();
    const gameId = getGameId(stats);
    await refreshReportedCache(gameId);

    const targets = collectReportablePlayers(stats);
    lastStatus = targets.length
      ? `${targets.length} player${targets.length === 1 ? '' : 's'} ready.`
      : 'No reportable players found in end-game stats.';
    currentLpl.log.info(`end-game stats loaded via ${reason}: ${lastStatus}`);
    renderPanel();
    return stats;
  } catch (error) {
    if (error?.status !== 404) {
      currentLpl.log.warn(`end-game stats lookup failed via ${reason}: ${formatError(error)}`);
    }
    return null;
  }
}

const shouldShowPanel = () => Boolean(currentEogStats);

const getPendingTargets = () => {
  const gameId = getGameId(currentEogStats);
  const candidates = isPreviewStats(currentEogStats)
    ? collectReportablePlayers(currentEogStats)
    : collectReportablePlayers(currentEogStats);
  return candidates.filter(
    (player) => !reportedCache.has(reportKey(gameId, player.puuid)),
  );
};

const selectAllPreviewTargets = () => {
  selectedPreviewPuuids = new Set(
    getPendingTargets()
      .map((player) => normalizePuuid(player.puuid))
      .filter(Boolean),
  );
};

const getSelectedPreviewTargets = () => {
  if (!isPreviewStats(currentEogStats) || !selectedPreviewPuuids.size) return [];
  return getPendingTargets().filter((player) =>
    selectedPreviewPuuids.has(normalizePuuid(player.puuid)),
  );
};

const ensurePanel = () => {
  let panel = document.getElementById(PANEL_ID);
  if (panel) return panel;

  panel = document.createElement('div');
  panel.id = PANEL_ID;
  document.body.appendChild(panel);
  return panel;
};

const renderPanel = () => {
  const panel = ensurePanel();
  if (!shouldShowPanel()) {
    panel.hidden = true;
    return;
  }

  const gameId = getGameId(currentEogStats);
  const categories = getSelectedCategories();
  const targets = getPendingTargets();
  const previewMode = isPreviewStats(currentEogStats);
  const selectedPreviewTargets = getSelectedPreviewTargets();
  const partyNote =
    settingsState.includeRandomTeammates && !partySnapshotCaptured
      ? 'Party snapshot missing; same-team players are excluded.'
      : `${partySnapshotCaptured ? partyPuuids.size || partySummonerIds.size : 0} lobby member${(partyPuuids.size || partySummonerIds.size) === 1 ? '' : 's'} protected.`;
  const rows = targets.length
    ? targets
        .map(
          (player) => {
            const selected =
              previewMode && selectedPreviewPuuids.has(normalizePuuid(player.puuid));
            const content = `
              <span>${escapeHtml(playerName(player))}</span>
              <small>${escapeHtml(player.championName || 'Player')}</small>
            `;
            if (!previewMode) {
              return `<div class="lpl-auto-reporter-player">${content}</div>`;
            }

            return `
              <button
                type="button"
                class="lpl-auto-reporter-player lpl-auto-reporter-choice${selected ? ' is-selected' : ''}"
                data-lpl-auto-reporter-action="toggle-preview-target"
                data-lpl-auto-reporter-puuid="${escapeHtml(player.puuid)}"
              >
                ${content}
              </button>
            `;
          },
        )
        .join('')
    : '<div class="lpl-auto-reporter-empty">No unreported players found.</div>';
  const submitDisabled = previewMode
    ? reportInFlight || !selectedPreviewTargets.length || !categories.length
    : reportInFlight || !targets.length || !categories.length;

  panel.hidden = false;
  panel.innerHTML = `
    <div class="lpl-auto-reporter-card">
      <div class="lpl-auto-reporter-kicker">LPL</div>
      <div class="lpl-auto-reporter-title">Report Assistant${previewMode ? ' Preview' : ''}</div>
      <div class="lpl-auto-reporter-meta">Game ${escapeHtml(gameId || 'unknown')} | ${escapeHtml(lastStatus)}</div>
      ${previewMode ? `<div class="lpl-auto-reporter-meta">${selectedPreviewTargets.length}/${targets.length} pending players selected. Click a row to exclude it.</div>` : ''}
      <div class="lpl-auto-reporter-list">${rows}</div>
      <button
        type="button"
        class="lpl-auto-reporter-submit"
        data-lpl-auto-reporter-action="submit"
        ${submitDisabled ? 'disabled' : ''}
      >
        ${previewMode ? (reportInFlight ? 'Reporting selected players...' : selectedPreviewTargets.length ? `Report ${selectedPreviewTargets.length} selected` : 'Select at least one player') : reportInFlight ? 'Reporting...' : `Report ${targets.length} player${targets.length === 1 ? '' : 's'}`}
      </button>
      <div class="lpl-auto-reporter-note">
        ${categories.length ? `${categories.length} configured categor${categories.length === 1 ? 'y' : 'ies'}.` : 'No report categories enabled.'}
        ${escapeHtml(partyNote)}
      </div>
    </div>
  `;
};

async function submitReports() {
  if (!currentLpl || reportInFlight || !currentEogStats) return;

  const categories = getSelectedCategories();
  if (!categories.length) {
    lastStatus = 'Enable at least one report category in plugin settings.';
    renderPanel();
    return;
  }

  const gameId = getGameId(currentEogStats);
  if (isPreviewStats(currentEogStats)) {
    const targets = getSelectedPreviewTargets();
    if (!gameId || !targets.length) {
      lastStatus = 'Select at least one unreported enemy from the last game first.';
      renderPanel();
      return;
    }

    reportInFlight = true;
    lastStatus = `Reporting ${targets.length} selected enem${targets.length === 1 ? 'y' : 'ies'} from last game preview...`;
    renderPanel();

    let success = 0;
    let failed = 0;

    for (const target of targets) {
      const key = reportKey(gameId, target.puuid);
      const payload = buildReportPayload(gameId, target, categories);

      try {
        currentLpl.log.info(
          `preview report submit via match history endpoint: game=${gameId} target=${playerName(target)} categories=${categories.join(',')}`,
        );
        await currentLpl.league.lcuRequest('POST', MATCH_HISTORY_REPORT_PATH, payload);
        reportedCache.add(key);
        selectedPreviewPuuids.delete(normalizePuuid(target.puuid));
        success += 1;
        currentLpl.log.info(`preview reported ${playerName(target)} (${target.puuid})`);
        await sleep(125);
      } catch (error) {
        failed += 1;
        currentLpl.log.warn(
          `Preview match-history report failed for ${playerName(target)}: ${formatError(error)}`,
        );
      }
    }

    reportInFlight = false;
    lastStatus =
      failed > 0
        ? `Submitted ${success} preview report${success === 1 ? '' : 's'}; ${failed} failed.`
        : `Submitted ${success} preview report${success === 1 ? '' : 's'}.`;
    renderPanel();
    return;
  }

  const targets = getPendingTargets();
  if (!gameId || !targets.length) {
    lastStatus = 'No reportable players available.';
    renderPanel();
    return;
  }

  reportInFlight = true;
  lastStatus = `Reporting ${targets.length} player${targets.length === 1 ? '' : 's'}...`;
  renderPanel();

  let success = 0;
  let failed = 0;

  for (const player of targets) {
    const key = reportKey(gameId, player.puuid);
    const payload = buildReportPayload(gameId, player, categories, {
      includeObfuscated: true,
    });

    try {
      await currentLpl.league.lcuRequest('POST', REPORT_PATH, payload);
      reportedCache.add(key);
      success += 1;
      currentLpl.log.info(`reported ${playerName(player)} (${player.puuid})`);
      await sleep(125);
    } catch (error) {
      failed += 1;
      currentLpl.log.warn(`failed to report ${playerName(player)}: ${formatError(error)}`);
    }
  }

  reportInFlight = false;
  lastStatus =
    failed > 0
      ? `Submitted ${success}; ${failed} failed.`
      : `Submitted ${success} report${success === 1 ? '' : 's'}.`;
  renderPanel();
}

export async function load(lpl) {
  currentLpl = lpl;
  currentSummoner = null;
  currentEogStats = null;
  reportedCache = new Set();
  partyPuuids = new Set();
  partySummonerIds = new Set();
  partySnapshotCaptured = false;
  previewModeActive = false;
  selectedPreviewPuuids = new Set();
  cleanupFns = [];
  reportInFlight = false;
  lastStatus = 'Waiting for end-game stats.';

  cleanupFns.push(installReportRequestLogger(lpl));

  await restorePartySnapshot();

  const { values } = lpl.settings.register({
    fields: [
      {
        type: 'toggle',
        key: 'includeRandomTeammates',
        label: 'Include random teammates',
        description: 'Report same-team players too, except yourself and players captured from your lobby party.',
        default: true,
      },
      {
        type: 'toggle',
        key: 'showLastGamePreview',
        label: 'Show last game preview',
        description: 'Preview your latest match with all reportable players selected for one-click reporting.',
        default: false,
      },
      ...REPORT_CATEGORIES.map((category) => ({
        type: 'toggle',
        key: category.key,
        label: category.label,
        description: category.description,
        default: category.default,
      })),
      {
        type: 'text',
        key: 'reportComment',
        label: 'Report comment',
        description: 'Optional comment included with submitted reports.',
        default: '',
        placeholder: 'Optional',
      },
    ],
  });

  settingsState = {
    includeRandomTeammates: true,
    showLastGamePreview: false,
    reportComment: '',
    ...Object.fromEntries(REPORT_CATEGORIES.map((category) => [category.key, category.default])),
    ...values,
  };

  lpl.settings.onChange((key, value, nextValues) => {
    settingsState = {
      ...settingsState,
      ...nextValues,
    };
    lpl.log.info(`setting ${key} changed to ${value}`);
    if (key === 'showLastGamePreview' || key === 'includeRandomTeammates') {
      void refreshLastGamePreview(`setting ${key}`);
    }
    renderPanel();
  });

  lpl.dom.addStyle(`
    #${PANEL_ID} {
      position: fixed;
      right: 22px;
      bottom: 24px;
      z-index: 2147483647;
      width: 310px;
      font-family: "LoL Body", "LoL Display", sans-serif;
      color: rgb(240, 230, 210);
    }
    #${PANEL_ID}[hidden] {
      display: none !important;
    }
    #${PANEL_ID} .lpl-auto-reporter-card {
      border: 1px solid rgba(198, 160, 80, 0.34);
      background: linear-gradient(180deg, rgba(18, 16, 13, 0.98), rgba(8, 9, 11, 0.98));
      box-shadow: 0 18px 44px rgba(0, 0, 0, 0.48);
      padding: 14px;
    }
    #${PANEL_ID} .lpl-auto-reporter-kicker {
      color: rgb(198, 160, 80);
      font: 700 10px/1 "LoL Display", sans-serif;
      letter-spacing: 0;
      margin-bottom: 5px;
    }
    #${PANEL_ID} .lpl-auto-reporter-title {
      font: 700 16px/1.15 "LoL Display", sans-serif;
      margin-bottom: 6px;
    }
    #${PANEL_ID} .lpl-auto-reporter-meta,
    #${PANEL_ID} .lpl-auto-reporter-note,
    #${PANEL_ID} .lpl-auto-reporter-empty {
      color: rgba(240, 230, 210, 0.68);
      font-size: 12px;
      line-height: 1.35;
    }
    #${PANEL_ID} .lpl-auto-reporter-list {
      display: grid;
      gap: 6px;
      margin: 12px 0;
      max-height: 168px;
      overflow: auto;
    }
    #${PANEL_ID} .lpl-auto-reporter-player {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      border-top: 1px solid rgba(198, 160, 80, 0.16);
      padding-top: 6px;
      font-size: 12px;
    }
    #${PANEL_ID} .lpl-auto-reporter-choice {
      width: 100%;
      border-right: 0;
      border-bottom: 0;
      border-left: 0;
      background: transparent;
      color: inherit;
      cursor: pointer;
      font: inherit;
      text-align: left;
    }
    #${PANEL_ID} .lpl-auto-reporter-choice:hover,
    #${PANEL_ID} .lpl-auto-reporter-choice.is-selected {
      color: rgb(255, 245, 210);
      background: rgba(198, 160, 80, 0.1);
    }
    #${PANEL_ID} .lpl-auto-reporter-choice.is-selected {
      box-shadow: inset 2px 0 0 rgba(198, 160, 80, 0.9);
      padding-left: 8px;
    }
    #${PANEL_ID} .lpl-auto-reporter-player small {
      color: rgba(240, 230, 210, 0.55);
      white-space: nowrap;
    }
    #${PANEL_ID} .lpl-auto-reporter-submit {
      width: 100%;
      min-height: 30px;
      border: 1px solid rgba(198, 160, 80, 0.72);
      background: rgba(198, 160, 80, 0.16);
      color: rgb(240, 230, 210);
      font: 700 12px/1 "LoL Display", sans-serif;
      cursor: pointer;
    }
    #${PANEL_ID} .lpl-auto-reporter-submit:hover:not(:disabled) {
      background: rgba(198, 160, 80, 0.26);
    }
    #${PANEL_ID} .lpl-auto-reporter-submit:disabled {
      cursor: default;
      opacity: 0.5;
    }
    #${PANEL_ID} .lpl-auto-reporter-note {
      margin-top: 8px;
    }
  `);

  const panel = ensurePanel();
  const onClick = (event) => {
    const target = event.target instanceof Element ? event.target : null;
    const choice = target?.closest('[data-lpl-auto-reporter-action="toggle-preview-target"]');
    if (choice) {
      event.preventDefault();
      event.stopPropagation();
      const puuid = normalizePuuid(choice.getAttribute('data-lpl-auto-reporter-puuid'));
      if (puuid) {
        if (selectedPreviewPuuids.has(puuid)) {
          selectedPreviewPuuids.delete(puuid);
        } else {
          selectedPreviewPuuids.add(puuid);
        }
      }
      lastStatus = `${getSelectedPreviewTargets().length}/${getPendingTargets().length} pending players selected.`;
      renderPanel();
      return;
    }

    if (!target?.closest('[data-lpl-auto-reporter-action="submit"]')) return;
    event.preventDefault();
    event.stopPropagation();
    void submitReports();
  };
  panel.addEventListener('click', onClick);
  cleanupFns.push(() => panel.removeEventListener('click', onClick));

  cleanupFns.push(
    lpl.league.on(
      LOBBY_PATH,
      (event) => {
        void (async () => {
          const reason = event?.source === 'seed' ? 'lobby seed' : 'lobby event';
          await capturePartySnapshot(event, reason);
          if (settingsState.showLastGamePreview) {
            await refreshLastGamePreview(reason);
          }
        })();
      },
      { seed: true },
    ),
  );

  cleanupFns.push(
    lpl.league.on(
      EOG_STATS_PATH,
      (event) => {
        const stats = normalizeEogStats(event);
        if (stats) {
          currentEogStats = stats;
          void loadEogStats(event?.source === 'seed' ? 'eog seed' : 'eog event');
        }
      },
      { seed: true },
    ),
  );

  cleanupFns.push(
    lpl.league.onPhaseChange((phase) => {
      const nextPhase = String(phase || '');
      if (nextPhase === 'EndOfGame' || nextPhase === 'PreEndOfGame') {
        void loadEogStats(`gameflow ${nextPhase}`);
        return;
      }

      if (nextPhase === 'Lobby' || nextPhase === 'Matchmaking' || nextPhase === 'ChampSelect') {
        if (settingsState.showLastGamePreview) {
          void refreshLastGamePreview(`gameflow ${nextPhase}`);
        } else {
          currentEogStats = null;
          selectedPreviewPuuids = new Set();
          lastStatus = 'Waiting for end-game stats.';
          renderPanel();
        }
      }

      if (
        nextPhase === 'Lobby' ||
        nextPhase === 'Matchmaking' ||
        nextPhase === 'ReadyCheck' ||
        nextPhase === 'ChampSelect' ||
        nextPhase === 'GameStart' ||
        nextPhase === 'InProgress' ||
        nextPhase === 'Reconnect'
      ) {
        void refreshPartySnapshot(`gameflow ${nextPhase}`);
      }
    }),
  );

  try {
    const session = await lpl.league.lcuRequest('GET', GAMEFLOW_SESSION_PATH);
    const phase = String(session?.phase || '');
    if (phase === 'EndOfGame' || phase === 'PreEndOfGame') {
      await loadEogStats(`initial gameflow ${phase}`);
    } else if (settingsState.showLastGamePreview) {
      await refreshLastGamePreview('startup');
    } else {
      renderPanel();
    }
  } catch {
    if (settingsState.showLastGamePreview) {
      await refreshLastGamePreview('startup');
    } else {
      renderPanel();
    }
  }

  lpl.log.info('auto reporter armed');

  return () => {
    cleanupFns.forEach((cleanup) => {
      try {
        cleanup?.();
      } catch {}
    });
    cleanupFns = [];
    document.getElementById(PANEL_ID)?.remove();
    currentLpl = null;
    currentSummoner = null;
    currentEogStats = null;
    reportInFlight = false;
    reportedCache = new Set();
    partyPuuids = new Set();
    partySummonerIds = new Set();
    partySnapshotCaptured = false;
    previewModeActive = false;
    selectedPreviewPuuids = new Set();
  };
}
