const EOG_STATS_PATH = '/lol-end-of-game/v1/eog-stats-block';
const GAMEFLOW_SESSION_PATH = '/lol-gameflow/v1/session';
const LOBBY_PATH = '/lol-lobby/v2/lobby';
const CURRENT_SUMMONER_PATH = '/lol-summoner/v1/current-summoner';
const REPORT_PATH = '/lol-player-report-sender/v1/end-of-game-reports';
const REPORTED_PLAYERS_PATH = '/lol-player-report-sender/v1/reported-players/gameId';

const TOAST_ID = 'lpl-auto-reporter-toast';

const REPORT_CATEGORIES = [
  { key: 'verbalAbuse',        value: 'VERBAL_ABUSE',        label: 'Verbal abuse',        description: 'Report abusive or harassing chat.',                              default: false },
  { key: 'negativeAttitude',   value: 'NEGATIVE_ATTITUDE',   label: 'Negative attitude',   description: 'Report griefing or refusal to cooperate.',                       default: false },
  { key: 'intentionalFeeding', value: 'ASSISTING_ENEMY_TEAM',label: 'Intentional feeding', description: 'Report intentional deaths or deliberate game sabotage.',         default: false },
  { key: 'leavingAfk',         value: 'LEAVING_AFK',         label: 'Leaving or AFK',      description: 'Report leaving the game or being AFK.',                          default: false },
  { key: 'hateSpeech',         value: 'HATE_SPEECH',         label: 'Hate speech',         description: 'Report identity-based harassment.',                              default: false },
  { key: 'cheating',           value: 'THIRD_PARTY_TOOLS',   label: 'Cheating',            description: 'Report scripting, botting, or third-party tool abuse.',         default: false },
  { key: 'offensiveName',      value: 'INAPPROPRIATE_NAME',  label: 'Offensive name',      description: 'Report an offensive Riot ID or summoner name.',                  default: false },
];

let currentLpl = null;
let currentSummoner = null;
let settingsState = { includeRandomTeammates: true, reportComment: '' };
let reportInFlight = false;
let reportedCache = new Set();
let partyPuuids = new Set();
let partySummonerIds = new Set();
let partySnapshotCaptured = false;
let cleanupFns = [];
let toastTimer = null;

const sleep = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

const formatError = (error) => {
  if (!error) return 'unknown error';
  if (typeof error === 'string') return error;
  if (error.body) return `${error.message || 'request failed'} (${error.body})`;
  return error.message || String(error);
};

const playerName = (player) => {
  const gameName = String(player?.riotIdGameName || '').trim();
  const tagLine  = String(player?.riotIdTagLine  || '').trim();
  if (gameName && tagLine) return `${gameName}#${tagLine}`;
  if (gameName) return gameName;
  return String(player?.summonerName || player?.puuid || 'Unknown player');
};

const normalizePuuid = (value) => String(value || '').trim().toLowerCase();

const normalizeSummonerId = (value) => {
  const id = Number(value || 0);
  return Number.isFinite(id) && id > 0 ? String(id) : '';
};

const normalizeEogStats = (payload) => {
  const stats = payload?.data ?? payload;
  if (!stats || typeof stats !== 'object' || !Array.isArray(stats.teams)) return null;
  return stats;
};

const getGameId = (stats) => {
  const value = stats?.reportGameId ?? stats?.gameId ?? stats?.localPlayer?.gameId;
  const id = Number(value || 0);
  return Number.isFinite(id) && id > 0 ? id : 0;
};

const getSelectedCategories = () =>
  REPORT_CATEGORIES.filter((c) => Boolean(settingsState[c.key])).map((c) => c.value);

const findLocalTeam = (stats) => {
  const localPuuid = String(stats?.localPlayer?.puuid || currentSummoner?.puuid || '').toLowerCase();
  const teams = Array.isArray(stats?.teams) ? stats.teams : [];
  return (
    teams.find((t) => t?.isPlayerTeam) ||
    teams.find((t) =>
      Array.isArray(t?.players) &&
      t.players.some((p) => p?.isLocalPlayer || (localPuuid && String(p?.puuid || '').toLowerCase() === localPuuid))
    ) ||
    null
  );
};

const isPartyMember = (player) => {
  const puuid      = normalizePuuid(player?.puuid);
  const summonerId = normalizeSummonerId(player?.summonerId);
  return (puuid && partyPuuids.has(puuid)) || (summonerId && partySummonerIds.has(summonerId));
};

const collectReportablePlayers = (stats) => {
  const teams      = Array.isArray(stats?.teams) ? stats.teams : [];
  const localTeam  = findLocalTeam(stats);
  const localTeamId = Number(localTeam?.teamId ?? stats?.localPlayer?.teamId ?? 0);
  const localPuuid  = String(stats?.localPlayer?.puuid || currentSummoner?.puuid || '').toLowerCase();

  const players = [];
  for (const team of teams) {
    const sameTeam =
      team === localTeam ||
      team?.isPlayerTeam ||
      (localTeamId && Number(team?.teamId || 0) === localTeamId);

    if (sameTeam && !settingsState.includeRandomTeammates) continue;
    if (sameTeam && !partySnapshotCaptured) continue;

    for (const player of Array.isArray(team?.players) ? team.players : []) {
      const puuid = String(player?.puuid || '').trim();
      if (!puuid || player?.botPlayer || player?.isLocalPlayer) continue;
      if (localPuuid && puuid.toLowerCase() === localPuuid) continue;
      if (sameTeam && isPartyMember(player)) continue;
      players.push(player);
    }
  }
  return players;
};

const reportKey = (gameId, puuid) => `${gameId}:${String(puuid || '').toLowerCase()}`;

const buildReportPayload = (gameId, player, categories) => {
  const payload = {
    comment: String(settingsState.reportComment || ''),
    gameId,
    categories,
    offenderSummonerId: Number(player?.summonerId || 0),
    offenderPuuid: String(player?.puuid || ''),
  };
  if (!Number.isFinite(payload.offenderSummonerId) || payload.offenderSummonerId <= 0) {
    delete payload.offenderSummonerId;
  }
  if (player?.obfuscatedPuuid) payload.obfuscatedOffenderPuuid = String(player.obfuscatedPuuid);
  return payload;
};

const showToast = (message) => {
  if (toastTimer) { window.clearTimeout(toastTimer); toastTimer = null; }

  let toast = document.getElementById(TOAST_ID);
  if (!toast) {
    toast = document.createElement('div');
    toast.id = TOAST_ID;
    document.body.appendChild(toast);
  }

  toast.style.cssText = [
    'position:fixed', 'bottom:20px', 'left:20px', 'z-index:2147483647',
    'background:rgba(8,9,11,0.93)', 'border:1px solid rgba(198,160,80,0.55)',
    'color:rgb(240,230,210)', 'font:700 13px/1.35 "LoL Display","LoL Body",sans-serif',
    'padding:9px 14px', 'pointer-events:none', 'opacity:1',
    'transition:opacity 0.4s', 'max-width:260px', 'box-shadow:0 8px 24px rgba(0,0,0,0.5)',
  ].join(';');
  toast.textContent = message;

  toastTimer = window.setTimeout(() => {
    if (toast) toast.style.opacity = '0';
    toastTimer = window.setTimeout(() => { toast?.remove(); toastTimer = null; }, 400);
  }, 4000);
};

const persistPartySnapshot = async () => {
  if (!currentLpl) return;
  try {
    await currentLpl.storage.set('lastPartySnapshot', {
      capturedAt: Date.now(),
      puuids: Array.from(partyPuuids),
      summonerIds: Array.from(partySummonerIds),
    });
  } catch (error) {
    currentLpl.log.warn(`party snapshot save failed: ${formatError(error)}`);
  }
};

const restorePartySnapshot = async () => {
  if (!currentLpl) return;
  try {
    const snapshot = await currentLpl.storage.get('lastPartySnapshot', null);
    if (!snapshot || typeof snapshot !== 'object') return;
    const ageMs = Date.now() - Number(snapshot.capturedAt || 0);
    if (!Number.isFinite(ageMs) || ageMs > 8 * 60 * 60 * 1000) return;
    partyPuuids      = new Set((Array.isArray(snapshot.puuids)      ? snapshot.puuids      : []).map(normalizePuuid).filter(Boolean));
    partySummonerIds = new Set((Array.isArray(snapshot.summonerIds) ? snapshot.summonerIds : []).map(normalizeSummonerId).filter(Boolean));
    partySnapshotCaptured = partyPuuids.size > 0 || partySummonerIds.size > 0;
  } catch (error) {
    currentLpl.log.warn(`party snapshot restore failed: ${formatError(error)}`);
  }
};

const capturePartySnapshot = async (payload, reason) => {
  if (!currentLpl) return;
  const members = Array.isArray((payload?.data ?? payload)?.members) ? (payload?.data ?? payload).members : [];
  if (!members.length) return;
  partyPuuids      = new Set(members.map((m) => normalizePuuid(m?.puuid)).filter(Boolean));
  partySummonerIds = new Set(members.map((m) => normalizeSummonerId(m?.summonerId)).filter(Boolean));
  partySnapshotCaptured = partyPuuids.size > 0 || partySummonerIds.size > 0;
  await persistPartySnapshot();
  currentLpl.log.info(`party snapshot captured via ${reason}: ${partyPuuids.size || partySummonerIds.size} member(s)`);
};

const refreshPartySnapshot = async (reason) => {
  if (!currentLpl) return;
  try {
    await capturePartySnapshot(await currentLpl.league.lcuRequest('GET', LOBBY_PATH), reason);
  } catch (error) {
    if (error?.status !== 404) currentLpl.log.warn(`party snapshot lookup failed via ${reason}: ${formatError(error)}`);
  }
};

const refreshReportedCache = async (gameId) => {
  if (!currentLpl || !gameId) return;
  try {
    const reported = await currentLpl.league.lcuRequest('GET', `${REPORTED_PLAYERS_PATH}/${encodeURIComponent(String(gameId))}`);
    for (const item of Array.isArray(reported) ? reported : []) {
      const puuid = item?.offenderPuuid || item?.reportedPuuid || item?.puuid || item?.playerPuuid || item;
      if (typeof puuid === 'string' && puuid) reportedCache.add(reportKey(gameId, puuid));
    }
  } catch (error) {
    if (error?.status !== 404) currentLpl.log.warn(`reported-player lookup failed: ${formatError(error)}`);
  }
};

const loadCurrentSummoner = async () => {
  if (!currentLpl) return;
  try {
    currentSummoner = await currentLpl.league.lcuRequest('GET', CURRENT_SUMMONER_PATH);
  } catch (error) {
    currentLpl.log.warn(`current summoner lookup failed: ${formatError(error)}`);
  }
};

async function submitReports(stats) {
  if (!currentLpl || reportInFlight || !stats) return;

  const categories = getSelectedCategories();
  if (!categories.length) {
    currentLpl.log.warn('auto-reporter: no categories enabled — configure in plugin settings');
    return;
  }

  const gameId = getGameId(stats);
  const targets = collectReportablePlayers(stats).filter(
    (p) => !reportedCache.has(reportKey(gameId, p.puuid))
  );

  if (!gameId || !targets.length) {
    currentLpl.log.info('auto-reporter: no unreported players found');
    return;
  }

  reportInFlight = true;
  currentLpl.log.info(`auto-reporter: reporting ${targets.length} player(s) — game ${gameId}`);

  let success = 0;
  let failed  = 0;

  for (const player of targets) {
    try {
      await currentLpl.league.lcuRequest('POST', REPORT_PATH, buildReportPayload(gameId, player, categories));
      reportedCache.add(reportKey(gameId, player.puuid));
      success += 1;
      currentLpl.log.info(`reported ${playerName(player)}`);
      await sleep(125);
    } catch (error) {
      failed += 1;
      currentLpl.log.warn(`failed to report ${playerName(player)}: ${formatError(error)}`);
    }
  }

  reportInFlight = false;

  const msg = failed > 0
    ? `Auto Reporter: ${success} reported, ${failed} failed`
    : `Auto Reporter: ${success} player${success === 1 ? '' : 's'} reported`;
  showToast(msg);
  currentLpl.log.info(msg);
}

async function loadEogStats(reason) {
  if (!currentLpl) return;
  try {
    const stats = normalizeEogStats(await currentLpl.league.lcuRequest('GET', EOG_STATS_PATH));
    if (!stats) return;

    await loadCurrentSummoner();
    const gameId = getGameId(stats);
    await refreshReportedCache(gameId);

    const pending = collectReportablePlayers(stats).filter(
      (p) => !reportedCache.has(reportKey(gameId, p.puuid))
    );
    currentLpl.log.info(`auto-reporter: EOG loaded via ${reason} — ${pending.length} target(s)`);

    if (pending.length) void submitReports(stats);
  } catch (error) {
    if (error?.status !== 404) currentLpl.log.warn(`EOG stats fetch failed via ${reason}: ${formatError(error)}`);
  }
}

export async function load(lpl) {
  currentLpl           = lpl;
  currentSummoner      = null;
  reportedCache        = new Set();
  partyPuuids          = new Set();
  partySummonerIds     = new Set();
  partySnapshotCaptured = false;
  cleanupFns           = [];
  reportInFlight       = false;
  toastTimer           = null;

  await restorePartySnapshot();

  const { values } = lpl.settings.register({
    fields: [
      {
        type: 'toggle',
        key: 'includeRandomTeammates',
        label: 'Include random teammates',
        description: 'Also report same-team players, except yourself and anyone in your pre-game lobby.',
        default: true,
      },
      ...REPORT_CATEGORIES.map((c) => ({
        type: 'toggle',
        key: c.key,
        label: c.label,
        description: c.description,
        default: c.default,
      })),
      {
        type: 'text',
        key: 'reportComment',
        label: 'Report comment',
        description: 'Optional comment included with every report.',
        default: '',
        placeholder: 'Optional',
      },
    ],
  });

  settingsState = {
    includeRandomTeammates: true,
    reportComment: '',
    ...Object.fromEntries(REPORT_CATEGORIES.map((c) => [c.key, c.default])),
    ...values,
  };

  lpl.settings.onChange((_key, _value, nextValues) => {
    settingsState = { ...settingsState, ...nextValues };
  });

  cleanupFns.push(
    lpl.league.on(LOBBY_PATH, (event) => {
      void capturePartySnapshot(event, event?.source === 'seed' ? 'lobby seed' : 'lobby event');
    }, { seed: true }),
  );

  cleanupFns.push(
    lpl.league.on(EOG_STATS_PATH, (event) => {
      if (normalizeEogStats(event)) void loadEogStats(event?.source === 'seed' ? 'eog seed' : 'eog event');
    }, { seed: true }),
  );

  cleanupFns.push(
    lpl.league.onPhaseChange((phase) => {
      const p = String(phase || '');
      if (p === 'EndOfGame' || p === 'PreEndOfGame') {
        void loadEogStats(`gameflow ${p}`);
      }
      if (['Lobby','Matchmaking','ReadyCheck','ChampSelect','GameStart','InProgress','Reconnect'].includes(p)) {
        void refreshPartySnapshot(`gameflow ${p}`);
      }
    }),
  );

  try {
    const session = await lpl.league.lcuRequest('GET', GAMEFLOW_SESSION_PATH);
    const phase   = String(session?.phase || '');
    if (phase === 'EndOfGame' || phase === 'PreEndOfGame') void loadEogStats(`startup ${phase}`);
  } catch {}

  lpl.log.info('auto reporter armed');

  return () => {
    cleanupFns.forEach((fn) => { try { fn?.(); } catch {} });
    cleanupFns = [];
    document.getElementById(TOAST_ID)?.remove();
    if (toastTimer) { window.clearTimeout(toastTimer); toastTimer = null; }
    currentLpl        = null;
    currentSummoner   = null;
    reportInFlight    = false;
    reportedCache     = new Set();
    partyPuuids       = new Set();
    partySummonerIds  = new Set();
    partySnapshotCaptured = false;
  };
}
