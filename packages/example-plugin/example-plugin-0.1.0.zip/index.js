const LOAD_BADGE_ID = 'lpl-example-load-badge';
const READY_BADGE_ID = 'lpl-example-ready-badge';
const LOAD_BADGE_SELECTOR = `#${LOAD_BADGE_ID}`;
const READY_BADGE_SELECTOR = `#${READY_BADGE_ID}`;

const ACCENT_THEMES = {
  gold: {
    loadBg: '#c89b3c',
    readyBg: '#6dd3ff',
    text: '#111',
  },
  ice: {
    loadBg: '#6dd3ff',
    readyBg: '#c89b3c',
    text: '#111',
  },
};

let currentLpl = null;
let readySeen = false;
let settingsState = {
  showReadyBadge: true,
  accent: 'gold',
};

function removeBadges(lpl) {
  if (lpl) {
    lpl.dom.removeElement(LOAD_BADGE_SELECTOR);
    lpl.dom.removeElement(READY_BADGE_SELECTOR);
    return;
  }

  document.querySelectorAll(`${LOAD_BADGE_SELECTOR}, ${READY_BADGE_SELECTOR}`).forEach((node) => {
    node.remove();
  });
}

function themeColors() {
  return ACCENT_THEMES[settingsState.accent] || ACCENT_THEMES.gold;
}

function updateBadgeAppearance(id, background) {
  const badge = document.getElementById(id);
  if (!badge) return;
  badge.style.background = background;
  badge.style.color = themeColors().text;
}

function syncBadges() {
  if (!currentLpl) return;

  updateBadgeAppearance(LOAD_BADGE_ID, themeColors().loadBg);

  if (readySeen && settingsState.showReadyBadge) {
    if (!document.getElementById(READY_BADGE_ID)) {
      currentLpl.dom.addElement(
        'body',
        `<div id="${READY_BADGE_ID}" class="lpl-example-badge">LPL Ready</div>`,
      );
    }
    updateBadgeAppearance(READY_BADGE_ID, themeColors().readyBg);
  } else {
    currentLpl.dom.removeElement(READY_BADGE_SELECTOR);
  }
}

export async function load(lpl) {
  currentLpl = lpl;
  readySeen = false;
  removeBadges(lpl);

  const { values } = lpl.settings.register({
    fields: [
      {
        type: 'toggle',
        key: 'showReadyBadge',
        label: 'Show ready badge',
        description: 'Display the gold or blue Ready badge after the client:ready event fires.',
        default: true,
      },
      {
        type: 'select',
        key: 'accent',
        label: 'Accent theme',
        description: 'Swap which badge gets the League gold highlight.',
        options: [
          { label: 'Gold', value: 'gold' },
          { label: 'Ice', value: 'ice' },
        ],
        default: 'gold',
      },
    ],
  });

  settingsState = {
    ...settingsState,
    ...values,
  };

  lpl.settings.onChange((key, value, nextValues) => {
    settingsState = {
      ...settingsState,
      ...nextValues,
    };
    lpl.log.info(`setting ${key} changed to ${value}`);
    syncBadges();
  });

  const count = (await lpl.storage.get('loadCount', 0)) + 1;
  await lpl.storage.set('loadCount', count);

  lpl.log.info(`loaded ${count} time(s)`);

  lpl.dom.addStyle(`
    .lpl-example-badge {
      position: fixed;
      right: 8px;
      font-size: 11px;
      font-weight: 700;
      padding: 2px 6px;
      border-radius: 3px;
      z-index: 2147483647;
      pointer-events: none;
    }

    #${LOAD_BADGE_ID} {
      bottom: 36px;
    }

    #${READY_BADGE_ID} {
      bottom: 8px;
    }
  `);

  lpl.dom.addElement('body', `<div id="${LOAD_BADGE_ID}" class="lpl-example-badge">LPL Load</div>`);
  syncBadges();

  lpl.events.on('client:ready', () => {
    readySeen = true;
    lpl.log.info('client:ready received');
    syncBadges();
  });
}

export async function unload() {
  currentLpl = null;
  readySeen = false;
  removeBadges();
}
