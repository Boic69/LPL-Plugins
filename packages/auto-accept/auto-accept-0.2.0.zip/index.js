const READY_CHECK_PATH = '/lol-matchmaking/v1/ready-check';
const READY_CHECK_ACCEPT_PATH = '/lol-matchmaking/v1/ready-check/accept';

let currentLpl = null;
let settingsState = {
  useGameflowFallback: true,
  retryOnFailure: true,
  acceptDelay: 0,
};
let acceptInFlight = false;
let pendingAcceptTimeout = null; // setTimeout handle for delayed accept

const sleep = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

const formatError = (error) => {
  if (!error) return 'unknown error';
  if (typeof error === 'string') return error;
  if (error.body) return `${error.message || 'request failed'} (${error.body})`;
  return error.message || String(error);
};

const normalizeReadyCheck = (payload) => {
  if (!payload || typeof payload !== 'object') return null;
  return {
    state: String(payload.state || ''),
    playerResponse: String(payload.playerResponse || 'None'),
    timer: Number(payload.timer ?? 0),
  };
};

const shouldAcceptReadyCheck = (readyCheck) =>
  readyCheck?.state === 'InProgress' && readyCheck?.playerResponse === 'None';

function cancelPendingAccept() {
  if (pendingAcceptTimeout !== null) {
    window.clearTimeout(pendingAcceptTimeout);
    pendingAcceptTimeout = null;
  }
}

async function acceptReadyCheck(reason) {
  if (!currentLpl) return false;
  if (acceptInFlight) {
    currentLpl.log.info(`accept skipped; request already in flight (${reason})`);
    return false;
  }

  acceptInFlight = true;

  try {
    currentLpl.log.info(`accepting ready-check via ${reason}`);
    await currentLpl.league.lcuRequest('POST', READY_CHECK_ACCEPT_PATH);
    currentLpl.log.info('ready-check accepted');
    return true;
  } catch (error) {
    currentLpl.log.warn(`accept failed via ${reason}: ${formatError(error)}`);

    if (settingsState.retryOnFailure) {
      await sleep(100);
      try {
        await currentLpl.league.lcuRequest('POST', READY_CHECK_ACCEPT_PATH);
        currentLpl.log.info('ready-check accepted on retry');
        return true;
      } catch (retryError) {
        currentLpl.log.warn(`accept retry failed: ${formatError(retryError)}`);
      }
    }

    return false;
  } finally {
    acceptInFlight = false;
  }
}

async function handleReadyCheckEvent(envelope, reason) {
  const readyCheck = normalizeReadyCheck(envelope?.data ?? envelope);
  if (!readyCheck) return;

  if (!shouldAcceptReadyCheck(readyCheck)) {
    cancelPendingAccept();
    acceptInFlight = false;
    return;
  }

  // Already waiting — don't reschedule.
  if (pendingAcceptTimeout !== null) return;

  const delay = Number(settingsState.acceptDelay) || 0;

  if (delay <= 0) {
    await acceptReadyCheck(reason);
    return;
  }

  // GET the endpoint to get the real current elapsed time, then wait only
  // the remaining gap rather than the full delay from this (possibly late) event.
  let elapsed = readyCheck.timer;
  try {
    const live = await currentLpl.league.lcuRequest('GET', READY_CHECK_PATH);
    const liveCheck = normalizeReadyCheck(live);
    if (liveCheck && shouldAcceptReadyCheck(liveCheck)) {
      elapsed = liveCheck.timer;
    } else if (liveCheck) {
      // Ready check already resolved between the event and the GET.
      cancelPendingAccept();
      acceptInFlight = false;
      return;
    }
  } catch {
    // Fallback to event timer if the GET fails.
  }

  const remaining = Math.max(0, delay - elapsed);
  currentLpl.log.info(`ready-check detected, elapsed=${elapsed}s, accepting in ${remaining}s`);

  if (remaining === 0) {
    await acceptReadyCheck(reason);
    return;
  }

  pendingAcceptTimeout = window.setTimeout(() => {
    pendingAcceptTimeout = null;
    void acceptReadyCheck(`${reason} (delayed ${delay}s)`);
  }, remaining * 1000);
}

async function seedReadyCheck(reason) {
  if (!currentLpl) return;

  try {
    const readyCheck = await currentLpl.league.lcuRequest('GET', READY_CHECK_PATH);
    await handleReadyCheckEvent({ data: readyCheck }, reason);
  } catch (error) {
    if (error?.status !== 404) {
      currentLpl.log.warn(`ready-check seed failed via ${reason}: ${formatError(error)}`);
    }
    acceptInFlight = false;
  }
}

export async function load(lpl) {
  currentLpl = lpl;
  acceptInFlight = false;
  pendingAcceptTimeout = null;

  const { values } = lpl.settings.register({
    fields: [
      {
        type: 'toggle',
        key: 'useGameflowFallback',
        label: 'Use gameflow fallback',
        description: 'Seed ready-check state again when the client phase changes to ReadyCheck.',
        default: true,
      },
      {
        type: 'toggle',
        key: 'retryOnFailure',
        label: 'Retry once on failure',
        description: 'Retry the accept request once after 100ms if the first call fails.',
        default: true,
      },
      {
        type: 'number',
        key: 'acceptDelay',
        label: 'Accept delay (seconds)',
        description: 'Wait this many seconds after the ready-check appears before accepting. 0 = accept immediately.',
        default: 0,
        min: 0,
        max: 10,
        step: 1,
      },
    ],
  });

  settingsState = {
    ...settingsState,
    ...values,
  };

  lpl.settings.onChange((key, value, nextValues) => {
    settingsState = {
      ...settingsState,
      ...nextValues,
    };
    lpl.log.info(`setting ${key} changed to ${value}`);
  });

  lpl.log.info('auto-accept armed');

  const offReadyCheck = lpl.league.on(
    READY_CHECK_PATH,
    (event) => {
      void handleReadyCheckEvent(
        event,
        event?.source === 'seed' ? 'ready-check seed' : 'ready-check event',
      );
    },
    { seed: true },
  );

  const offPhaseChange = lpl.league.onPhaseChange((phase, event) => {
    if (!settingsState.useGameflowFallback) return;
    if (String(phase || '') !== 'ReadyCheck') return;

    void seedReadyCheck(event?.source === 'seed' ? 'phase seed' : 'gameflow fallback');
  });

  return () => {
    cancelPendingAccept();
    offReadyCheck?.();
    offPhaseChange?.();
    currentLpl = null;
    acceptInFlight = false;
  };
}
