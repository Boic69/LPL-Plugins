'use strict';

const EVENTS_PATH = '/_lpl/events';
const CODE_KEY = 'csr-access-code';
const URGENT_MS = 5000;

const $ = (id) => document.getElementById(id);
const iconUrl = (id) => `https://cdn.communitydragon.org/latest/champion/${id}/square`;

let champions = [];
let championsById = new Map();
let state = { inChampSelect: false };
let stateReceivedAt = 0;
let selectedId = 0;
let lastActionId = null;
let showAll = false;
let busy = false;
let view = 'champion';

// ── Data ──────────────────────────────────────────────────────────────────────

function storedCode() {
  try {
    return localStorage.getItem(CODE_KEY) || '';
  } catch {
    return '';
  }
}

function storeCode(code) {
  try {
    localStorage.setItem(CODE_KEY, code);
  } catch {}
}

async function api(path, body, retried = false) {
  const res = await fetch(path, body === undefined ? {} : {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Access-Code': storedCode() },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => null);

  // Only when "Require access code" is on in the plugin's LPL settings.
  if (res.status === 401 && !retried) {
    const code = window.prompt('Enter the access code from Champ Select Remote\'s settings in LPL:');
    if (code) {
      storeCode(code.trim().toUpperCase());
      return api(path, body, true);
    }
  }
  if (!res.ok) throw new Error(data?.error || `${res.status} ${res.statusText}`);
  return data;
}

async function loadChampions() {
  while (!champions.length) {
    try {
      champions = await api('/api/champions');
      championsById = new Map(champions.map((c) => [c.id, c]));
      renderGrid();
      renderTeams();
    } catch {
      await new Promise((r) => setTimeout(r, 2000));
    }
  }
}

async function refreshState() {
  try {
    applyState(await api('/api/state'));
  } catch (e) {
    showMessage(e.message, true);
  }
}

function connectEvents() {
  const events = new EventSource(EVENTS_PATH);
  const link = $('conn');
  events.addEventListener('open', () => {
    link.classList.add('is-up');
    link.setAttribute('aria-label', 'Connected to League');
    refreshState();
  });
  events.addEventListener('error', () => {
    link.classList.remove('is-up');
    link.setAttribute('aria-label', 'Reconnecting to League');
  });
  events.addEventListener('state', (e) => applyState(JSON.parse(e.data)));
  // Rune pages changed, here or in the client.
  events.addEventListener('loadout', () => {
    if (view === 'loadout') loadLoadout();
    else loadout = null;
  });
}

// ── Actions ───────────────────────────────────────────────────────────────────

const actionType = () => (state.action?.type === 'ban' ? 'ban' : 'pick');
const isMyTurn = () => Boolean(state.action?.isInProgress);
const nameOf = (id) => championsById.get(id)?.name ?? 'that champion';

function availableIds() {
  if (!state.inChampSelect) return null;
  const ids = actionType() === 'ban' ? state.bannable : state.pickable;
  return ids?.length ? new Set(ids) : null; // null = unknown, allow everything
}

// Ready to lock in or ban; the Core stays lit through in-flight requests.
const isReady = () => {
  const available = availableIds();
  return isMyTurn() && selectedId > 0 && !(available && !available.has(selectedId));
};
const canCommit = () => !busy && isReady();

async function select(championId, lock) {
  if (busy) return;
  busy = true;
  renderDock();
  try {
    applyState(await api('/api/select', { championId, lock }));
    const verb = lock ? (actionType() === 'ban' ? 'Banned' : 'Locked in') : 'Hovering';
    showMessage(`${verb} ${nameOf(championId)}`);
  } catch (e) {
    showMessage(e.message, true);
  } finally {
    busy = false;
    renderDock();
  }
}

function choose(championId) {
  const available = availableIds();
  if (available && !available.has(championId)) return;
  selectedId = championId;
  renderGrid();
  renderDock();
  select(championId, false);
}

// ── State → UI ────────────────────────────────────────────────────────────────

function applyState(next) {
  state = next || { inChampSelect: false };
  stateReceivedAt = performance.now();

  const actionId = state.action?.id ?? null;
  if (actionId !== lastActionId) {
    lastActionId = actionId;
    selectedId = state.action?.championId || 0;
  }

  document.body.classList.toggle('is-ban', actionType() === 'ban');
  document.body.classList.toggle('is-my-turn', isMyTurn());

  renderStatus();
  renderClock();
  renderTeams();
  renderGrid();
  renderDock();

  // Recommended runes depend on the champion, so refetch when it changes.
  if (loadout && currentChampionId() !== loadoutChampion) {
    if (view === 'loadout') loadLoadout();
    else loadout = null;
  } else if (loadout && view === 'loadout') {
    renderSpells();
  }
}

function renderStatus() {
  const action = state.action;
  let title;
  let hint;

  if (!state.inChampSelect) {
    title = 'Not in champ select';
    hint = 'This page updates on its own when champ select starts.';
  } else if (state.timer?.phase === 'PLANNING') {
    title = 'Declare your pick';
    hint = 'Tap a champion to show your team what you want to play.';
  } else if (isMyTurn()) {
    title = action.type === 'ban' ? 'Your turn to ban' : 'Your turn to pick';
    hint = action.type === 'ban'
      ? 'Tap a champion, then tap Ban.'
      : 'Tap a champion, then tap Lock in.';
  } else if (action) {
    title = 'Waiting for your turn';
    hint = 'You can still hover the champion you want to pick.';
  } else if (state.timer?.phase === 'FINALIZATION') {
    title = 'Picks are locked';
    hint = 'Last chance to swap runes and skins in the client.';
  } else {
    title = 'Waiting';
    hint = 'Nothing left for you to pick or ban.';
  }

  $('phase').textContent = title;
  $('hint').textContent = hint;
}

function remainingMs() {
  return Math.max(0, (state.timer?.remainingMs || 0) - (performance.now() - stateReceivedAt));
}

function renderClock() {
  const active = state.inChampSelect && state.timer?.remainingMs > 0;
  $('clock').hidden = !active;

  const left = active ? remainingMs() : 0;
  $('seconds').textContent = String(Math.ceil(left / 1000));
  $('clock').classList.toggle('is-urgent', active && isMyTurn() && left <= URGENT_MS);

  // The Core's ring drains with the phase timer.
  const total = state.timer?.totalMs || state.timer?.remainingMs || 1;
  const fraction = active ? Math.min(1, left / total) : 0;
  $('ring-time').style.strokeDashoffset = String(100 - fraction * 100);
}

function renderTeams() {
  $('teams').hidden = !state.inChampSelect;
  if (!state.inChampSelect) return;

  const slots = (members) =>
    members.map((m) => {
      const slot = document.createElement('div');
      slot.className = 'slot';
      const shown = m.championId || m.pickIntent;
      if (shown) {
        slot.style.backgroundImage = `url(${iconUrl(shown)})`;
        slot.title = nameOf(shown);
      }
      if (!m.championId && m.pickIntent) slot.classList.add('is-intent');
      if (m.isMe) slot.classList.add('is-me');
      return slot;
    });

  const bans = (ids) =>
    ids.map((id) => {
      const ban = document.createElement('div');
      ban.className = 'ban-icon';
      ban.style.backgroundImage = `url(${iconUrl(id)})`;
      ban.title = `${nameOf(id)} (banned)`;
      return ban;
    });

  $('my-team').replaceChildren(...slots(state.myTeam || []));
  $('their-team').replaceChildren(...slots(state.theirTeam || []));
  $('my-bans').replaceChildren(...bans(state.bans?.myTeam || []));
  $('their-bans').replaceChildren(...bans(state.bans?.theirTeam || []));
}

function visibleChampions() {
  const query = $('search').value.trim().toLowerCase();
  const available = availableIds();
  return champions.filter((c) => {
    if (query && !c.name.toLowerCase().includes(query) && !c.alias.toLowerCase().includes(query)) {
      return false;
    }
    return showAll || !available || available.has(c.id);
  });
}

function renderGrid() {
  const grid = $('view-champion');
  if (!champions.length) {
    grid.innerHTML = '<p class="empty">Loading champions from the League client…</p>';
    return;
  }

  const available = availableIds();
  const items = visibleChampions().map((c) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'champ';
    button.dataset.id = c.id;
    const unavailable = Boolean(available && !available.has(c.id));
    button.classList.toggle('is-selected', c.id === selectedId);
    button.classList.toggle('is-unavailable', unavailable);
    button.setAttribute('aria-pressed', String(c.id === selectedId));
    if (unavailable) button.setAttribute('aria-disabled', 'true');

    const img = document.createElement('img');
    img.loading = 'lazy';
    img.decoding = 'async';
    img.alt = '';
    img.src = iconUrl(c.id);
    const name = document.createElement('span');
    name.textContent = c.name;
    button.append(img, name);
    return button;
  });

  if (!items.length) {
    const query = $('search').value.trim();
    grid.innerHTML = '';
    const empty = document.createElement('p');
    empty.className = 'empty';
    empty.textContent = query ? `No champion matches “${query}”.` : 'No champions available right now.';
    grid.append(empty);
    return;
  }
  grid.replaceChildren(...items);
}

function renderDock() {
  const champ = championsById.get(selectedId);
  const portrait = $('chosen-portrait');
  portrait.style.backgroundImage = champ ? `url(${iconUrl(champ.id)})` : '';
  $('chosen-name').textContent = champ ? champ.name : 'No champion selected';

  const core = $('core');
  const label = actionType() === 'ban' ? 'Ban' : 'Lock in';
  $('core-label').textContent = label;
  core.disabled = !canCommit();
  core.classList.toggle('is-live', isReady());
  core.classList.toggle('is-busy', busy);
  core.setAttribute('aria-label', champ ? `${label} ${champ.name}` : label);
}

function showMessage(text, isError = false) {
  const message = $('message');
  message.textContent = text || '';
  message.classList.toggle('is-error', isError);
}

// ── Loadout: spells and runes ─────────────────────────────────────────────────

let loadout = null;
let loadoutChampion = null;
let spellSlot = 0;
// Rune editor: main = [keystone, row1, row2, row3]; secondary = up to two
// { row, perk } from different rows; shards = one per shard row.
let editor = null;

const styleById = (id) => loadout?.styles.find((s) => s.id === id);
const spellById = (id) => loadout?.spells.find((s) => s.id === id);
const perkIcon = (id) => loadout?.perks[id]?.icon || '';

function currentChampionId() {
  const me = state.myTeam?.find((m) => m.isMe);
  return me?.championId || me?.pickIntent || 0;
}

async function loadLoadout() {
  try {
    loadout = await api('/api/loadout');
    loadoutChampion = currentChampionId();
    if (!editor?.dirty) editor = editorFromPage(loadout.pages.find((p) => p.current));
    renderLoadout();
  } catch (e) {
    showMessage(e.message, true);
  }
}

function editorFromPage(page) {
  const primary = styleById(page?.primaryStyleId) ?? loadout.styles[0];
  const subId = page?.subStyleId !== primary.id && styleById(page?.subStyleId) ? page.subStyleId : primary.subStyles[0];
  const sub = styleById(subId);
  const ids = page?.selectedPerkIds || [];

  const main = primary.rows.map((row) => ids.find((id) => row.includes(id)) || 0);
  const secondary = [];
  sub?.rows.forEach((row, index) => {
    const id = index > 0 && ids.find((x) => row.includes(x));
    if (id && secondary.length < 2) secondary.push({ row: index, perk: id });
  });
  // Shard ids repeat across rows, so they're matched by position.
  const shards = primary.shards.map((row, i) => (row.includes(ids[6 + i]) ? ids[6 + i] : 0));
  return { primary: primary.id, sub: subId, main, secondary, shards, dirty: false };
}

const editorPerkIds = () => [
  ...editor.main,
  ...[...editor.secondary].sort((a, b) => a.row - b.row).map((s) => s.perk),
  ...editor.shards,
];
const editorComplete = () =>
  editor.sub && editor.secondary.length === 2 && editorPerkIds().every((id) => id > 0);

function editRunes(change, perkId) {
  change();
  editor.dirty = true;
  if (perkId) describePerk(perkId);
  renderEditor();
}

function describePerk(id) {
  const perk = loadout.perks[id];
  const info = $('perk-info');
  info.replaceChildren();
  if (!perk) return;
  const name = document.createElement('strong');
  name.textContent = perk.name;
  info.append(name, perk.description ? ` ${perk.description}` : '');
}

async function run(task, success) {
  if (busy) return;
  busy = true;
  renderDock();
  try {
    await task();
    showMessage(success);
  } catch (e) {
    showMessage(e.message, true);
  } finally {
    busy = false;
    renderDock();
  }
}

function setSpell(spellId) {
  const next = [...(state.mySpells || [0, 0])];
  const other = 1 - spellSlot;
  if (next[other] === spellId) next[other] = next[spellSlot]; // picking the other slot's spell swaps them
  next[spellSlot] = spellId;
  const key = spellSlot === 0 ? 'D' : 'F';
  run(async () => {
    applyState(await api('/api/spells', { spell1Id: next[0], spell2Id: next[1] }));
  }, `${spellById(spellId)?.name ?? 'Spell'} on ${key}`);
}

function saveRunes() {
  const primary = styleById(editor.primary);
  run(async () => {
    loadout = await api('/api/runes', {
      primaryStyleId: editor.primary,
      subStyleId: editor.sub,
      selectedPerkIds: editorPerkIds(),
    });
    editor = editorFromPage(loadout.pages.find((p) => p.current));
    renderLoadout();
  }, `Saved ${primary?.name ?? ''} runes`);
}

function useRecommended(rec) {
  run(async () => {
    loadout = await api('/api/runes', rec);
    if (state.inChampSelect && rec.spells.length === 2) {
      applyState(await api('/api/spells', { spell1Id: rec.spells[0], spell2Id: rec.spells[1] }));
    }
    editor = editorFromPage(loadout.pages.find((p) => p.current));
    renderLoadout();
  }, `Using ${rec.keystone} runes`);
}

function selectPage(page) {
  run(async () => {
    loadout = await api('/api/runes/page', { pageId: page.id });
    editor = editorFromPage(loadout.pages.find((p) => p.current));
    renderLoadout();
  }, `Switched to ${page.name}`);
}

function renderLoadout() {
  if (!loadout) return;
  renderSpells();
  renderPages();
  renderRecommended();
  renderEditor();
}

function renderSpells() {
  const [d, f] = state.mySpells || [0, 0];
  $('spells-note').textContent = state.inChampSelect ? '' : 'Can be changed in champ select';

  document.querySelectorAll('.spell-slot').forEach((slot) => {
    const index = Number(slot.dataset.slot);
    const spell = spellById(index === 0 ? d : f);
    slot.setAttribute('aria-pressed', String(index === spellSlot));
    slot.querySelector('.spell-face').style.backgroundImage = spell?.icon ? `url(${spell.icon})` : '';
    slot.querySelector('.spell-name').textContent = spell?.name ?? 'None';
  });

  $('spell-grid').replaceChildren(...loadout.spells.map((spell) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'spell';
    button.dataset.id = spell.id;
    button.title = spell.description;
    button.disabled = !state.inChampSelect;
    button.classList.toggle('is-equipped', spell.id === d || spell.id === f);
    const img = document.createElement('img');
    img.alt = '';
    img.src = spell.icon;
    const name = document.createElement('span');
    name.textContent = spell.name;
    button.append(img, name);
    return button;
  }));
}

function renderPages() {
  $('pages').replaceChildren(...loadout.pages.map((page) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'page';
    button.setAttribute('aria-pressed', String(page.current));
    const img = document.createElement('img');
    img.alt = '';
    img.src = perkIcon(page.selectedPerkIds[0]) || styleById(page.primaryStyleId)?.icon || '';
    const name = document.createElement('span');
    name.textContent = page.name;
    button.append(img, name);
    button.addEventListener('click', () => { if (!page.current) selectPage(page); });
    return button;
  }));
}

function renderRecommended() {
  const recs = loadout.recommended || [];
  $('recommended-block').hidden = !recs.length;
  if (!recs.length) return;
  const champ = championsById.get(loadout.championId);
  $('recommended-title').textContent = champ ? `Recommended for ${champ.name}` : 'Recommended';

  $('recommended').replaceChildren(...recs.map((rec) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'rec';

    const keystone = document.createElement('img');
    keystone.className = 'rec-keystone';
    keystone.alt = '';
    keystone.src = perkIcon(rec.selectedPerkIds[0]);

    const text = document.createElement('span');
    text.className = 'rec-text';
    const title = document.createElement('strong');
    title.textContent = rec.keystone;
    const trees = document.createElement('span');
    trees.textContent = `${styleById(rec.primaryStyleId)?.name ?? ''} with ${styleById(rec.subStyleId)?.name ?? ''}`;
    text.append(title, trees);

    const icons = document.createElement('span');
    icons.className = 'rec-icons';
    for (const id of rec.spells) {
      const img = document.createElement('img');
      img.alt = spellById(id)?.name ?? '';
      img.src = spellById(id)?.icon ?? '';
      icons.append(img);
    }

    button.append(keystone, text, icons);
    button.addEventListener('click', () => useRecommended(rec));
    return button;
  }));
}

function runeButton(id, pressed, onPick) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'rune';
  button.setAttribute('aria-pressed', String(pressed));
  button.setAttribute('aria-label', loadout.perks[id]?.name ?? String(id));
  const img = document.createElement('img');
  img.alt = '';
  img.src = perkIcon(id);
  button.append(img);
  button.addEventListener('click', onPick);
  return button;
}

function runeRow(ids, isPicked, onPick, modifier) {
  const row = document.createElement('div');
  row.className = `rune-row${modifier ? ` ${modifier}` : ''}`;
  row.append(...ids.map((id) => runeButton(id, isPicked(id), () => onPick(id))));
  return row;
}

function treePicker(ids, selected, onPick) {
  const pick = document.createElement('div');
  pick.className = 'tree-pick';
  pick.append(...ids.map((id) => {
    const style = styleById(id);
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'tree-choice';
    button.setAttribute('aria-pressed', String(id === selected));
    button.setAttribute('aria-label', style?.name ?? String(id));
    const img = document.createElement('img');
    img.alt = '';
    img.src = style?.icon ?? '';
    button.append(img);
    button.addEventListener('click', () => onPick(id));
    return button;
  }));
  return pick;
}

function treeSection(title, modifier, ...children) {
  const section = document.createElement('div');
  section.className = `tree${modifier ? ` ${modifier}` : ''}`;
  const heading = document.createElement('h3');
  heading.textContent = title;
  section.append(heading, ...children);
  return section;
}

function renderEditor() {
  const primary = styleById(editor.primary);
  const sub = styleById(editor.sub);

  const pickPrimary = (id) => {
    if (id === editor.primary) return;
    editRunes(() => {
      const next = styleById(id);
      editor.primary = id;
      editor.main = next.rows.map(() => 0);
      editor.shards = next.shards.map((row, i) => (row.includes(editor.shards[i]) ? editor.shards[i] : 0));
      if (editor.sub === id || !next.subStyles.includes(editor.sub)) {
        editor.sub = next.subStyles[0];
        editor.secondary = [];
      }
    });
  };
  const pickSub = (id) => {
    if (id === editor.sub) return;
    editRunes(() => {
      editor.sub = id;
      editor.secondary = [];
    });
  };

  const mainRows = primary.rows.map((ids, rowIndex) =>
    runeRow(
      ids,
      (id) => editor.main[rowIndex] === id,
      (id) => editRunes(() => { editor.main[rowIndex] = id; }, id),
      rowIndex === 0 ? 'is-keystone' : '',
    ));

  // Secondary: any two rows below the keystone; a third choice drops the oldest.
  const subRows = (sub?.rows ?? []).slice(1).map((ids, i) => {
    const rowIndex = i + 1;
    return runeRow(
      ids,
      (id) => editor.secondary.some((s) => s.perk === id),
      (id) => editRunes(() => {
        const existing = editor.secondary.find((s) => s.row === rowIndex);
        if (existing) existing.perk = id;
        else editor.secondary.push({ row: rowIndex, perk: id });
        if (editor.secondary.length > 2) editor.secondary.shift();
      }, id),
    );
  });

  const shardRows = primary.shards.map((ids, rowIndex) =>
    runeRow(
      ids,
      (id) => editor.shards[rowIndex] === id,
      (id) => editRunes(() => { editor.shards[rowIndex] = id; }, id),
      'is-shard',
    ));

  $('rune-editor').replaceChildren(
    treeSection('Primary', '', treePicker(loadout.styles.map((s) => s.id), editor.primary, pickPrimary), ...mainRows),
    treeSection('Secondary', '', treePicker(primary.subStyles, editor.sub, pickSub), ...subRows),
    treeSection('Shards', 'is-shards', ...shardRows),
  );
  $('save-runes').disabled = !(editor.dirty && editorComplete());
}

function showView(next) {
  view = next;
  const loadoutView = next === 'loadout';
  $('tab-champion').setAttribute('aria-selected', String(!loadoutView));
  $('tab-loadout').setAttribute('aria-selected', String(loadoutView));
  $('view-champion').hidden = loadoutView;
  $('view-loadout').hidden = !loadoutView;
  $('finder').hidden = loadoutView;
  if (loadoutView) {
    if (loadout) renderLoadout();
    else loadLoadout();
  }
}

// ── Wiring ────────────────────────────────────────────────────────────────────

$('tab-champion').addEventListener('click', () => showView('champion'));
$('tab-loadout').addEventListener('click', () => showView('loadout'));

document.querySelectorAll('.spell-slot').forEach((slot) => {
  slot.addEventListener('click', () => {
    spellSlot = Number(slot.dataset.slot);
    renderSpells();
  });
});

$('spell-grid').addEventListener('click', (e) => {
  const button = e.target.closest('.spell');
  if (button && !button.disabled) setSpell(Number(button.dataset.id));
});

$('save-runes').addEventListener('click', () => {
  if (editor && editorComplete()) saveRunes();
});

$('view-champion').addEventListener('click', (e) => {
  const button = e.target.closest('.champ');
  if (button) choose(Number(button.dataset.id));
});

$('search').addEventListener('input', renderGrid);

$('search').addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const available = availableIds();
  const first = visibleChampions().find((c) => !available || available.has(c.id));
  if (!first) return;
  if (first.id === selectedId && canCommit()) select(first.id, true);
  else choose(first.id);
});

for (const [id, all] of [['scope-available', false], ['scope-all', true]]) {
  $(id).addEventListener('click', () => {
    showAll = all;
    $('scope-available').setAttribute('aria-pressed', String(!all));
    $('scope-all').setAttribute('aria-pressed', String(all));
    renderGrid();
  });
}

$('core').addEventListener('click', () => {
  if (canCommit()) select(selectedId, true);
});

setInterval(renderClock, 250);
// Safety net in case a pushed update is missed.
setInterval(() => { if (!busy) refreshState(); }, 3000);
renderGrid();
renderDock();
loadChampions();
connectEvents();
