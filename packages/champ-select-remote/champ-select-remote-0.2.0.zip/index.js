const SESSION_PATH = '/lol-champ-select/v1/session';
const ACTIONS_PATH = '/lol-champ-select/v1/session/actions';
const PICKABLE_PATH = '/lol-champ-select/v1/pickable-champion-ids';
const BANNABLE_PATH = '/lol-champ-select/v1/bannable-champion-ids';
const CHAMPIONS_PATH = '/lol-game-data/assets/v1/champion-summary.json';
const MY_SELECTION_PATH = '/lol-champ-select/v1/session/my-selection';
const PERKS_PATH = '/lol-perks/v1';
const SPELLS_PATH = '/lol-game-data/assets/v1/summoner-spells.json';
const GAMEFLOW_SESSION_PATH = '/lol-gameflow/v1/session';
const CDRAGON_ASSETS = 'https://raw.communitydragon.org/latest/plugins/rcp-be-lol-game-data/global/default/';
const REMOTE_PAGE_NAME = 'LPL Remote';
const DEFAULT_PORT = 6969;
const PUSH_DEBOUNCE_MS = 100;
// Addons add sections to the Runes & spells tab through this slot.
const SECTIONS_SLOT = 'champ-select-remote/loadout-sections';
const SECTION_TIMEOUT_MS = 20 * 1000;
// No 0/O/1/I/L so the code is easy to read off one screen and type on another.
const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

let currentLpl = null;
let server = null;
let champions = null;
let lastSession = null;
let pushTimer = null;
let loadoutPushTimer = null;
let runeData = null; // rune trees + perks; static for a client version
let spellData = null; // every summoner spell, filtered per game mode on use
let accessCode = '';
let localAddress = ''; // this PC's LAN IP, for the address shown in settings
let serverOptions = { port: DEFAULT_PORT, lan: false, requireCode: false };
let sectionsSlot = null;

const formatError = (e) => {
  if (!e) return 'unknown';
  if (typeof e === 'string') return e;
  if (e.body) return `${e.message || 'request failed'} (${e.body})`;
  return e.message || String(e);
};

const httpError = (status, message) => Object.assign(new Error(message), { status });

const lcu = (method, path, body) => currentLpl.league.lcuRequest(method, path, body);

async function getChampions() {
  if (champions) return champions;
  const list = await lcu('GET', CHAMPIONS_PATH);
  champions = (Array.isArray(list) ? list : [])
    .filter((c) => Number(c?.id) > 0)
    .map((c) => ({ id: Number(c.id), name: String(c.name || ''), alias: String(c.alias || '') }))
    .sort((a, b) => a.name.localeCompare(b.name));
  return champions;
}

async function fetchSession() {
  try {
    return await lcu('GET', SESSION_PATH);
  } catch (e) {
    if (e?.status === 404) return null;
    throw e;
  }
}

// Real champion ids only: the client pads these lists with -1 ("none").
async function fetchIds(path) {
  try {
    const ids = await lcu('GET', path);
    return Array.isArray(ids) ? ids.filter((id) => Number.isInteger(id) && id > 0) : [];
  } catch {
    return [];
  }
}

const flatActions = (session) => (Array.isArray(session?.actions) ? session.actions.flat() : []);

// The action a champion click applies to. On your own turn that's the
// in-progress pick/ban. Otherwise (planning, or someone else's turn) it's your
// pick, since hovering it declares your pick intent; bans can't be pre-hovered.
// The client flags the ban as in progress during PLANNING, so skip that case.
function findMyAction(session) {
  const mine = flatActions(session).filter(
    (a) =>
      a?.actorCellId === session.localPlayerCellId &&
      !a.completed &&
      (a.type === 'pick' || a.type === 'ban'),
  );
  const planning = session.timer?.phase === 'PLANNING';
  const current = planning ? null : mine.find((a) => a.isInProgress);
  return current ?? mine.find((a) => a.type === 'pick') ?? null;
}

async function buildState(session) {
  if (!session || typeof session !== 'object' || !Array.isArray(session.myTeam)) {
    return { inChampSelect: false };
  }

  const action = findMyAction(session);
  const [pickable, bannable] = await Promise.all([fetchIds(PICKABLE_PATH), fetchIds(BANNABLE_PATH)]);

  const me = session.myTeam.find((m) => m.cellId === session.localPlayerCellId);
  const bans = { myTeam: [], theirTeam: [] };
  for (const a of flatActions(session)) {
    if (a?.type === 'ban' && a.completed && a.championId > 0) {
      (a.isAllyAction ? bans.myTeam : bans.theirTeam).push(a.championId);
    }
  }

  const member = (m) => ({
    cellId: m.cellId,
    championId: Number(m.championId) || 0,
    pickIntent: Number(m.championPickIntent) || 0,
    position: String(m.assignedPosition || ''),
    isMe: m.cellId === session.localPlayerCellId,
  });

  return {
    inChampSelect: true,
    timer: {
      phase: String(session.timer?.phase || ''),
      remainingMs: Number(session.timer?.adjustedTimeLeftInPhase) || 0,
      totalMs: Number(session.timer?.totalTimeInPhase) || 0,
    },
    action: action
      ? {
          id: action.id,
          type: action.type,
          isInProgress: Boolean(action.isInProgress),
          championId: Number(action.championId) || 0,
        }
      : null,
    myTeam: session.myTeam.map(member),
    theirTeam: (Array.isArray(session.theirTeam) ? session.theirTeam : []).map(member),
    bans,
    pickable,
    bannable,
    mySpells: [Number(me?.spell1Id) || 0, Number(me?.spell2Id) || 0],
  };
}

async function selectChampion(championId, lock) {
  const session = await fetchSession();
  if (!session) throw httpError(409, 'Not in champ select');

  const action = findMyAction(session);
  if (!action) throw httpError(409, 'You have no pick or ban left');
  if (lock && !action.isInProgress) throw httpError(409, `It isn't your turn to ${action.type} yet`);

  const allowed = await fetchIds(action.type === 'ban' ? BANNABLE_PATH : PICKABLE_PATH);
  if (allowed.length && !allowed.includes(championId)) {
    throw httpError(409, 'That champion is not available');
  }

  // Locking is the same PATCH as hovering with `completed` set; the client
  // accepts POST …/complete with a 2xx but doesn't actually lock.
  await lcu('PATCH', `${ACTIONS_PATH}/${action.id}`, lock ? { championId, completed: true } : { championId });
  currentLpl.log.info(`${lock ? 'locked' : 'hovered'} ${action.type} champion=${championId}`);

  return buildState(await fetchSession());
}

// ── Loadout: summoner spells and runes ────────────────────────────────────────

// LCU asset paths aren't reachable from other devices; CommunityDragon mirrors them.
const assetUrl = (iconPath) => {
  const rest = String(iconPath || '').replace(/^\/lol-game-data\/assets\//i, '');
  return rest ? CDRAGON_ASSETS + rest.toLowerCase() : '';
};

const stripTags = (html) => String(html || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();

async function getRuneData() {
  if (runeData) return runeData;
  const [styles, perks] = await Promise.all([
    lcu('GET', `${PERKS_PATH}/styles`),
    lcu('GET', `${PERKS_PATH}/perks`),
  ]);

  const perkById = {};
  for (const p of Array.isArray(perks) ? perks : []) {
    perkById[p.id] = { id: p.id, name: p.name, icon: assetUrl(p.iconPath), description: stripTags(p.shortDesc) };
  }

  runeData = {
    // A tree's first slot is the keystone row; stat-mod slots are the shard rows.
    styles: (Array.isArray(styles) ? styles : [])
      .map((style) => ({
        id: style.id,
        name: style.name,
        icon: assetUrl(style.iconPath),
        subStyles: style.allowedSubStyles || [],
        rows: style.slots.filter((slot) => slot.type !== 'kStatMod').map((slot) => slot.perks),
        shards: style.slots.filter((slot) => slot.type === 'kStatMod').map((slot) => slot.perks),
      }))
      .sort((a, b) => a.id - b.id),
    perks: perkById,
  };
  return runeData;
}

async function getSpells(gameMode) {
  spellData ??= await lcu('GET', SPELLS_PATH);
  return (Array.isArray(spellData) ? spellData : [])
    .filter((s) => s.id > 0 && (!gameMode || s.gameModes?.includes(gameMode)))
    .map((s) => ({ id: s.id, name: s.name, icon: assetUrl(s.iconPath), description: stripTags(s.description) }))
    .sort((a, b) => a.name.localeCompare(b.name));
}

async function fetchRecommended(championId, position, mapId) {
  try {
    const pos = String(position || 'none').toLowerCase();
    const list = await lcu('GET', `${PERKS_PATH}/recommended-pages/champion/${championId}/position/${pos}/map/${mapId}`);
    return (Array.isArray(list) ? list : []).map((p) => ({
      keystone: p.keystone?.name || '',
      primaryStyleId: p.primaryPerkStyleId,
      subStyleId: p.secondaryPerkStyleId,
      selectedPerkIds: (p.perks || []).map((perk) => perk.id),
      spells: p.summonerSpellIds || [],
    }));
  } catch {
    return [];
  }
}

async function buildLoadout() {
  const [session, runes, pages, inventory, flow] = await Promise.all([
    fetchSession(),
    getRuneData(),
    lcu('GET', `${PERKS_PATH}/pages`),
    lcu('GET', `${PERKS_PATH}/inventory`).catch(() => null),
    lcu('GET', GAMEFLOW_SESSION_PATH).catch(() => null),
  ]);
  const me = session?.myTeam?.find((m) => m.cellId === session.localPlayerCellId);
  const championId = Number(me?.championId) || Number(me?.championPickIntent) || 0;
  const [spells, recommended] = await Promise.all([
    getSpells(flow?.gameData?.queue?.gameMode),
    championId ? fetchRecommended(championId, me?.assignedPosition, flow?.map?.id || 11) : [],
  ]);

  return {
    spells,
    styles: runes.styles,
    perks: runes.perks,
    pages: (Array.isArray(pages) ? pages : []).map((p) => ({
      id: p.id,
      name: p.name,
      isEditable: Boolean(p.isEditable),
      current: Boolean(p.current),
      primaryStyleId: p.primaryStyleId,
      subStyleId: p.subStyleId,
      selectedPerkIds: p.selectedPerkIds || [],
    })),
    canAddPage: Boolean(inventory?.canAddCustomPage),
    championId,
    recommended,
  };
}

async function setSpells(spell1Id, spell2Id) {
  if (!(await fetchSession())) throw httpError(409, 'Summoner spells can only be changed in champ select');
  if (spell1Id === spell2Id) throw httpError(400, 'Pick two different summoner spells');
  await lcu('PATCH', MY_SELECTION_PATH, { spell1Id, spell2Id });
  currentLpl.log.info(`spells set to ${spell1Id}, ${spell2Id}`);
}

async function selectRunePage(pageId) {
  await lcu('PUT', `${PERKS_PATH}/currentpage`, pageId);
  currentLpl.log.info(`rune page ${pageId} selected`);
}

// Saves into a dedicated "LPL Remote" page so the player's own pages are left
// alone: reuse it, else create it, else (no free slot) take over the current
// editable page.
async function saveRunes({ primaryStyleId, subStyleId, selectedPerkIds }) {
  const page = { name: REMOTE_PAGE_NAME, primaryStyleId, subStyleId, selectedPerkIds, current: true };
  const pages = await lcu('GET', `${PERKS_PATH}/pages`);
  const list = Array.isArray(pages) ? pages : [];

  let target = list.find((p) => p.isEditable && p.name === REMOTE_PAGE_NAME);
  if (!target) {
    const inventory = await lcu('GET', `${PERKS_PATH}/inventory`).catch(() => null);
    if (inventory?.canAddCustomPage) {
      const created = await lcu('POST', `${PERKS_PATH}/pages`, page);
      if (created?.id) await selectRunePage(created.id);
      currentLpl.log.info('runes saved to a new LPL Remote page');
      return;
    }
    target = list.find((p) => p.isEditable && p.current) ?? list.find((p) => p.isEditable);
  }
  if (!target) throw httpError(409, 'No editable rune page. Delete a rune page in the client, then try again.');

  await lcu('PUT', `${PERKS_PATH}/pages/${target.id}`, { ...target, ...page });
  await selectRunePage(target.id);
  currentLpl.log.info(`runes saved to page ${target.id}`);
}

const isIdList = (value, length) =>
  Array.isArray(value) && value.length === length && value.every((id) => Number.isInteger(id) && id > 0);

// ── Addon sections ────────────────────────────────────────────────────────────
//
// Contract (slot version 1): { apiVersion: 1, title, actions: [{ id, label,
// primary? }], load() → { note?, options: [{ id, title, subtitle?, badge?,
// icons?: [url] }] }, run(actionId, optionId) → { message? } }. The phone
// renders sections generically; everything an addon returns is cleaned here
// before it leaves this machine, and no addon code runs on the phone.

const cleanText = (value, max = 120) => String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
const cleanUrl = (value) => (/^https?:\/\//i.test(String(value ?? '')) ? String(value).slice(0, 500) : '');

const withTimeout = (promise, ms, message) => {
  let timer;
  return Promise.race([
    Promise.resolve(promise).finally(() => window.clearTimeout(timer)),
    new Promise((_, reject) => {
      timer = window.setTimeout(() => reject(httpError(504, message)), ms);
    }),
  ]);
};

function listSections() {
  if (!sectionsSlot) return [];
  return sectionsSlot
    .list()
    .filter((c) => typeof c.value.load === 'function' && typeof c.value.run === 'function')
    .map((c) => ({
      id: `${c.pluginId}:${c.id}`,
      title: cleanText(c.value.title || c.id, 60),
      actions: (Array.isArray(c.value.actions) ? c.value.actions : [])
        .slice(0, 6)
        .map((a) => ({ id: cleanText(a?.id, 40), label: cleanText(a?.label, 30), primary: Boolean(a?.primary) }))
        .filter((a) => a.id && a.label),
      contribution: c.value,
    }));
}

function findSection(id) {
  const section = listSections().find((s) => s.id === id);
  if (!section) throw httpError(404, 'That section is no longer available');
  return section;
}

const publicSection = ({ contribution, ...section }) => section;

async function loadSection(id) {
  const section = findSection(id);
  const result = await withTimeout(section.contribution.load(), SECTION_TIMEOUT_MS, `${section.title} took too long`);
  const options = (Array.isArray(result?.options) ? result.options : []).slice(0, 20).map((o) => ({
    id: cleanText(o?.id, 80),
    title: cleanText(o?.title),
    subtitle: cleanText(o?.subtitle, 160),
    badge: cleanText(o?.badge, 30),
    icons: (Array.isArray(o?.icons) ? o.icons : []).slice(0, 12).map(cleanUrl).filter(Boolean),
  }));
  return { ...publicSection(section), note: cleanText(result?.note, 200), options: options.filter((o) => o.id && o.title) };
}

async function runSection(id, actionId, optionId) {
  const section = findSection(id);
  if (!section.actions.some((a) => a.id === actionId)) throw httpError(400, 'Unknown action');
  const result = await withTimeout(
    section.contribution.run(actionId, String(optionId ?? '')),
    SECTION_TIMEOUT_MS,
    `${section.title} took too long`,
  );
  currentLpl.log.info(`section ${id}: ran ${actionId} on ${optionId}`);
  return { message: cleanText(result?.message, 200) };
}

function scheduleLoadoutPush() {
  if (loadoutPushTimer !== null) return;
  loadoutPushTimer = window.setTimeout(() => {
    loadoutPushTimer = null;
    server?.broadcast('loadout', null);
  }, PUSH_DEBOUNCE_MS);
}

function schedulePush() {
  if (pushTimer !== null) return;
  pushTimer = window.setTimeout(async () => {
    pushTimer = null;
    if (!server) return;
    try {
      server.broadcast('state', await buildState(lastSession));
    } catch (e) {
      currentLpl?.log.warn(`state push failed: ${formatError(e)}`);
    }
  }, PUSH_DEBOUNCE_MS);
}

async function loadAccessCode(lpl) {
  const stored = await lpl.storage.get('accessCode');
  if (typeof stored === 'string' && stored.length === 6) return stored;
  const bytes = crypto.getRandomValues(new Uint8Array(6));
  const code = Array.from(bytes, (b) => CODE_ALPHABET[b % CODE_ALPHABET.length]).join('');
  await lpl.storage.set('accessCode', code);
  return code;
}

function startServer({ port, lan, requireCode }) {
  server?.close();
  server = null;

  try {
    server = currentLpl.server.create({ port, host: lan ? '0.0.0.0' : '127.0.0.1', static: 'web' });
  } catch (e) {
    currentLpl.log.error(`could not start web server on port ${port}: ${formatError(e)}`);
    return;
  }

  server.get('/api/champions', () => getChampions());
  server.get('/api/state', async () => buildState(await fetchSession()));
  // Every write goes through here: the optional LAN access code, plus logging
  // failures, which otherwise only show up on the page.
  const write = (path, handler) =>
    server.post(path, async (req) => {
      if (lan && requireCode && String(req.headers['x-access-code'] || '').toUpperCase() !== accessCode) {
        throw httpError(401, 'Access code required');
      }
      try {
        return await handler(req.json() ?? {}, req);
      } catch (e) {
        currentLpl?.log.warn(`${path} failed: ${formatError(e)}`);
        throw e;
      }
    });

  write('/api/select', async ({ championId, lock }) => {
    const id = Number(championId);
    if (!Number.isInteger(id) || id <= 0) throw httpError(400, 'championId must be a positive integer');
    return selectChampion(id, Boolean(lock));
  });

  server.get('/api/loadout', () => buildLoadout());

  write('/api/spells', async ({ spell1Id, spell2Id }) => {
    const spells = [Number(spell1Id), Number(spell2Id)];
    if (!isIdList(spells, 2)) throw httpError(400, 'spell1Id and spell2Id must be positive integers');
    await setSpells(...spells);
    return buildState(await fetchSession());
  });

  write('/api/runes/page', async ({ pageId }) => {
    const id = Number(pageId);
    if (!Number.isInteger(id)) throw httpError(400, 'pageId must be an integer');
    await selectRunePage(id);
    return buildLoadout();
  });

  write('/api/runes', async ({ primaryStyleId, subStyleId, selectedPerkIds }) => {
    const styles = [Number(primaryStyleId), Number(subStyleId)];
    if (!isIdList(styles, 2) || styles[0] === styles[1]) {
      throw httpError(400, 'Pick two different rune trees');
    }
    if (!isIdList(selectedPerkIds, 9)) throw httpError(400, 'A rune page needs 9 runes');
    await saveRunes({ primaryStyleId: styles[0], subStyleId: styles[1], selectedPerkIds });
    return buildLoadout();
  });

  server.get('/api/sections', () => listSections().map(publicSection));
  server.get('/api/sections/:id', (req) => loadSection(req.params.id));
  write('/api/sections/:id/run', ({ actionId, optionId }, req) => runSection(req.params.id, String(actionId ?? ''), optionId));

  currentLpl.log.info(`open ${server.url} to pick and ban`);
  if (lan) {
    const code = requireCode ? `, access code ${accessCode}` : '';
    const address = localAddress ? `http://${localAddress}:${port}` : `http://<this PC's IP>:${port}`;
    currentLpl.log.info(`LAN access on: open ${address} on your phone${code}`);
  }
}

function readServerOptions(values) {
  return {
    port: Number(values.port) || DEFAULT_PORT,
    lan: Boolean(values.lanAccess),
    requireCode: Boolean(values.requireCode),
  };
}

export async function load(lpl) {
  if (!lpl.server) {
    lpl.log.error('This plugin needs a newer LPL with web server support. Update LPL, then reload it.');
    return undefined;
  }

  currentLpl = lpl;
  accessCode = await loadAccessCode(lpl);
  localAddress = lpl.server.localAddress?.() || '';

  const { values } = lpl.settings.register({
    fields: [
      {
        type: 'info',
        key: 'address',
        label: 'Address for your phone',
        description: localAddress
          ? "This PC's local IP. Turn on access from other devices below to use it."
          : 'This PC is not connected to a network.',
        value: (current) => (localAddress ? `http://${localAddress}:${Number(current.port) || DEFAULT_PORT}` : ''),
      },
      {
        type: 'number',
        key: 'port',
        label: 'Web server port',
        description: 'Open http://127.0.0.1:<port> in your browser during champ select.',
        default: DEFAULT_PORT,
        min: 1024,
        max: 65535,
        step: 1,
      },
      {
        type: 'toggle',
        key: 'lanAccess',
        label: 'Allow access from other devices',
        description: "Lets your phone open http://<this PC's IP>:<port> on the same network.",
        default: false,
      },
      {
        type: 'toggle',
        key: 'requireCode',
        label: 'Require access code',
        description: `With other devices allowed, picking and banning needs access code ${accessCode}, so others on your network can't do it for you.`,
        default: false,
      },
    ],
  });

  // Older LPL builds have no extension support; the tab then simply has no
  // addon sections.
  sectionsSlot = lpl.extensions?.define(SECTIONS_SLOT, { version: 1, api: Object.freeze({ assetUrl }) }) ?? null;
  const offSections = sectionsSlot?.onChange(() => server?.broadcast('sections', null));

  serverOptions = readServerOptions(values);
  startServer(serverOptions);

  lpl.settings.onChange((_key, _value, nextValues) => {
    const next = readServerOptions(nextValues);
    if (
      next.port === serverOptions.port &&
      next.lan === serverOptions.lan &&
      next.requireCode === serverOptions.requireCode
    ) {
      return;
    }
    serverOptions = next;
    startServer(serverOptions);
  });

  const offSession = lpl.league.on(
    SESSION_PATH,
    (event) => {
      const wasActive = Boolean(lastSession);
      lastSession = event?.eventType === 'Delete' ? null : event?.data ?? null;
      if (wasActive !== Boolean(lastSession)) {
        lpl.log.info(`champ select session ${lastSession ? 'started' : 'ended'} (${event?.source})`);
      }
      schedulePush();
    },
    { seed: true },
  );

  // Rune pages changed (here or in the client): tell pages to refetch.
  const offPerks = [`${PERKS_PATH}/currentpage`, `${PERKS_PATH}/pages`].map((path) =>
    lpl.league.on(path, scheduleLoadoutPush),
  );

  return () => {
    offSession?.();
    offPerks.forEach((off) => off?.());
    offSections?.();
    sectionsSlot = null;
    window.clearTimeout(pushTimer);
    window.clearTimeout(loadoutPushTimer);
    pushTimer = null;
    loadoutPushTimer = null;
    runeData = null;
    spellData = null;
    server?.close();
    server = null;
    champions = null;
    lastSession = null;
    currentLpl = null;
  };
}
