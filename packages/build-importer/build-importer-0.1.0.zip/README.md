# Build Importer

Imports runes, item sets and summoner spells in champ select. It doesn't know
any stats site itself: **provider addons** supply the builds.

Source is in `src/`; `index.js` is generated. After editing, run:

```
node tools/bundle-plugin.mjs plugins/build-importer
```

## Writing a provider addon

A provider is a plugin that contributes to the `build-importer/providers` slot
(contract version 1). Depend on Build Importer in `plugin.toml`, and declare
the hosts you fetch from:

```toml
[permissions]
network = true

[network]
hosts = ["example.com"]

[dependencies]
build-importer = "^0.1"
```

Contribute with a factory, so you get Build Importer's data classes from the
slot's `api` even if your addon loads first:

```js
export async function load(lpl) {
  lpl.extensions.contribute('build-importer/providers', 'example', ({ api }) => ({
    apiVersion: 1,
    name: 'Example',
    // query: api.BuildQuery — championId, championAlias ("MonkeyKing"),
    // championName, role ('top'|'jungle'|'middle'|'bottom'|'support', or ''
    // for the champion's main role), queueId, mapId.
    async fetchBuilds(query) {
      const res = await lpl.net.fetch(`https://example.com/${query.championAlias}`);
      const data = await res.json();
      return [
        new api.Build({
          label: 'Most popular',
          stats: { games: data.games, winRate: data.wr, patch: data.patch },
          runes: { primaryStyleId: 8100, subStyleId: 8200, perkIds: [/* 9 ids */] },
          spells: { spell1Id: 4, spell2Id: 14 },
          itemSet: {
            title: 'Example build',
            blocks: [api.ItemBlock.fromIds('Starting items', [1056, 2003, 2003])],
          },
        }),
      ];
    },
  }));
}
```

Rules for `fetchBuilds`:

- Return builds best-first; auto-import uses the first one.
- Any of `runes`, `spells`, `itemSet` may be `null` if you don't have it.
- Rune perks may be in any order within primary/secondary; Build Importer
  sorts them into rows against the client's rune trees and rejects pages that
  don't fit, so a bad page never reaches the client.
- Throw an `Error` with a readable message if the site fails; it's shown to
  the user. Answers taking over 20 seconds are abandoned.
- Results are cached for 30 minutes per champion, role, queue and map. If
  your addon has options that change its builds (a rank filter, say), add a
  `cacheKey()` method returning a string that changes with them.

## What it changes in the client

- One rune page named `LPL Build: …`, reused on every import. If no page slot
  is free, it takes over the current editable page.
- One item set per champion (uid `lpl-build-<championId>`). Other item sets,
  including other tools', are kept.
- Summoner spells, only during champ select.
