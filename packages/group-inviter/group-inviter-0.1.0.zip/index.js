const FRIEND_GROUPS_PATH = '/lol-chat/v1/friend-groups';
const FRIENDS_PATH = '/lol-chat/v1/friends';
const LOBBY_PATH = '/lol-lobby/v2/lobby';
const LOBBY_INVITATIONS_PATH = '/lol-lobby/v2/lobby/invitations';
const NATIVE_MENU_SELECTOR = 'lol-uikit-context-menu';
const NATIVE_ITEM_CLASS = 'lpl-group-inviter-native-item';

let currentLpl = null;
let settingsState = {
  includeMobileFriends: true,
};
let inviteInFlight = false;
let toastRoot = null;
let activeFolderName = '';
let activeRow = null;
let activeMenu = null;
let injectionToken = 0;
let toastTimers = [];

const normalizeText = (value) =>
  String(value || '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

const formatError = (error) => {
  if (!error) return 'unknown error';
  if (typeof error === 'string') return error;
  if (error.body) return `${error.message || 'request failed'} (${error.body})`;
  return error.message || String(error);
};

const isVisibleElement = (element) => {
  if (!(element instanceof Element)) return false;
  const rect = element.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
};

const pluralize = (count, singular, plural) => (count === 1 ? singular : plural);

const extractFolderName = (row) => {
  if (!(row instanceof Element)) return '';

  const label = row.querySelector('.group-label-locale-direction-override');
  if (label?.textContent) {
    return String(label.textContent).trim();
  }

  const raw = String(row.textContent || '').replace(/\s+/g, ' ').trim();
  return raw.replace(/\s*\(\d+\s*\/\s*\d+\)\s*$/, '').trim();
};

const ensureToastRoot = () => {
  if (toastRoot?.isConnected) return toastRoot;

  toastRoot = document.createElement('div');
  toastRoot.className = 'lpl-group-inviter-toasts';
  document.body.appendChild(toastRoot);
  return toastRoot;
};

const showToast = (message, variant = 'info') => {
  const root = ensureToastRoot();
  const toast = document.createElement('div');
  toast.className = `lpl-group-inviter-toast ${variant}`;
  toast.textContent = String(message || '');
  root.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add('is-visible'));

  const timer = window.setTimeout(() => {
    toast.classList.remove('is-visible');
    window.setTimeout(() => toast.remove(), 180);
  }, 2600);

  toastTimers.push(timer);
  return toast;
};

const resetActiveMenuState = () => {
  activeFolderName = '';
  activeRow = null;
  activeMenu = null;
};

const normalizeAvailability = (friend) =>
  String(friend?.availability || '')
    .trim()
    .toLowerCase();

const isProbablyLeaguePresence = (friend) => {
  if (!friend || typeof friend !== 'object') return false;
  const product = String(friend.product || '').toLowerCase();
  const productName = String(friend.productName || '').toLowerCase();
  const hasLolPayload =
    friend.lol && typeof friend.lol === 'object' && Object.keys(friend.lol).length > 0;

  return (
    product === 'league_of_legends' ||
    productName.includes('league') ||
    Boolean(friend.platformId) ||
    hasLolPayload
  );
};

const buildInvitationPayload = (friend) => {
  const payload = {};

  if (friend?.summonerId) {
    payload.toSummonerId = Number(friend.summonerId);
  }
  if (friend?.puuid) {
    payload.toPuuid = String(friend.puuid);
  }
  if (friend?.gameName) {
    payload.toSummonerName = String(friend.gameName);
  }

  return payload;
};

const getLobbyState = async () => {
  try {
    return await currentLpl.league.lcuRequest('GET', LOBBY_PATH);
  } catch (error) {
    if (error?.status === 404) {
      return null;
    }
    throw error;
  }
};

const resolveFolder = async (folderName) => {
  const [groups, friends] = await Promise.all([
    currentLpl.league.lcuRequest('GET', FRIEND_GROUPS_PATH),
    currentLpl.league.lcuRequest('GET', FRIENDS_PATH),
  ]);

  const normalizedFolderName = normalizeText(folderName);
  const group =
    (Array.isArray(groups)
      ? groups.find((item) => normalizeText(item?.name) === normalizedFolderName)
      : null) || null;

  const members = Array.isArray(friends)
    ? friends.filter((friend) => {
        const friendGroupName = normalizeText(friend?.groupName || friend?.displayGroupName);
        if (group && Number(friend?.groupId) === Number(group.id)) return true;
        return friendGroupName === normalizedFolderName;
      })
    : [];

  return {
    group,
    members,
  };
};

const getInviteableFriends = (members, lobby) => {
  const lobbyMemberIds = new Set(
    Array.isArray(lobby?.members)
      ? lobby.members
          .map((member) => Number(member?.summonerId || 0))
          .filter((summonerId) => Number.isFinite(summonerId) && summonerId > 0)
      : [],
  );

  const invitedIds = new Set(
    Array.isArray(lobby?.invitations)
      ? lobby.invitations
          .map((invite) => Number(invite?.toSummonerId || 0))
          .filter((summonerId) => Number.isFinite(summonerId) && summonerId > 0)
      : [],
  );

  return (Array.isArray(members) ? members : []).filter((friend) => {
    const summonerId = Number(friend?.summonerId || 0);
    const availability = normalizeAvailability(friend);

    if (!Number.isFinite(summonerId) || summonerId <= 0) return false;
    if (availability === 'offline') return false;
    if (!settingsState.includeMobileFriends && availability === 'mobile') return false;
    if (!isProbablyLeaguePresence(friend)) return false;
    if (lobbyMemberIds.has(summonerId)) return false;
    if (invitedIds.has(summonerId)) return false;

    return true;
  });
};

async function inviteFolder(folderName) {
  if (!currentLpl) return;
  if (inviteInFlight) {
    currentLpl.log.info(`invite skipped; request already in flight (${folderName})`);
    return;
  }

  inviteInFlight = true;

  try {
    const lobby = await getLobbyState();
    if (!lobby) {
      currentLpl.log.warn(`invite failed; no lobby is currently open (${folderName})`);
      showToast('Create or join a lobby before inviting a folder.', 'warn');
      return;
    }

    if (!lobby?.localMember?.allowedInviteOthers) {
      currentLpl.log.warn(`invite failed; local player cannot invite others (${folderName})`);
      showToast('Only the current lobby leader can invite players.', 'warn');
      return;
    }

    const { members } = await resolveFolder(folderName);
    const inviteable = getInviteableFriends(members, lobby);

    if (!inviteable.length) {
      currentLpl.log.info(`no inviteable friends found in folder ${folderName}`);
      showToast(`No online friends in ${folderName} are currently inviteable.`, 'info');
      return;
    }

    const payload = inviteable.map(buildInvitationPayload);
    currentLpl.log.info(
      `inviting ${payload.length} ${pluralize(payload.length, 'friend', 'friends')} from ${folderName}`,
    );

    await currentLpl.league.lcuRequest('POST', LOBBY_INVITATIONS_PATH, payload);

    showToast(
      `Invited ${payload.length} ${pluralize(payload.length, 'friend', 'friends')} from ${folderName}.`,
      'success',
    );
  } catch (error) {
    currentLpl.log.warn(`invite failed for ${folderName}: ${formatError(error)}`);
    showToast(`Invite failed for ${folderName}.`, 'error');
  } finally {
    inviteInFlight = false;
  }
}

const getNativeMenuRoot = (menu) => {
  const contextRoot = menu?.shadowRoot?.lastElementChild;
  return contextRoot instanceof Element ? contextRoot : null;
};

const findOpenNativeMenuForRow = (row) => {
  const menus = Array.from(document.querySelectorAll(NATIVE_MENU_SELECTOR));
  return menus.find((menu) => {
    if (!(menu instanceof HTMLElement)) return false;
    if (typeof menu.isOpen === 'function' && !menu.isOpen()) return false;
    if (!menu.parentNode) return false;

    const target = menu.target instanceof Element ? menu.target : null;
    if (!target) return false;

    const targetRow = target.closest('.lol-social-roster-group');
    if (!targetRow) return false;
    if (row && targetRow !== row) return false;
    if (!isVisibleElement(targetRow)) return false;

    const root = getNativeMenuRoot(menu);
    if (!root) return false;

    return true;
  }) || null;
};

const buildNativeMenuItem = (menu) => {
  const root = getNativeMenuRoot(menu);
  if (!root) return null;

  const template =
    root.querySelector('.menu-item') || root.firstElementChild;

  const item = template instanceof HTMLElement
    ? template.cloneNode(true)
    : document.createElement('div');

  if (!(item instanceof HTMLElement)) return null;

  item.className = 'menu-item';
  item.classList.add(NATIVE_ITEM_CLASS);
  item.textContent = 'Invite Folder';
  item.tabIndex = -1;
  item.removeAttribute('disabled');
  item.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();

    const folderName = activeFolderName;
    if (!folderName) return;

    if (typeof menu.close === 'function') {
      menu.close();
    }

    void inviteFolder(folderName);
    resetActiveMenuState();
  });

  return item;
};

const injectNativeMenuItem = (menu) => {
  const root = getNativeMenuRoot(menu);
  if (!root) return false;

  const existing = root.querySelector(`.${NATIVE_ITEM_CLASS}`);
  if (existing) return true;

  const item = buildNativeMenuItem(menu);
  if (!item) return false;

  root.appendChild(item);

  if (!menu.__lplGroupInviterCloseListener) {
    menu.__lplGroupInviterCloseListener = () => {
      resetActiveMenuState();
    };
    root.addEventListener('closeContextMenu', menu.__lplGroupInviterCloseListener);
  }

  activeMenu = menu;
  return true;
};

const scheduleNativeMenuInjection = (row) => {
  const token = ++injectionToken;
  let attempts = 0;

  const tick = () => {
    if (token !== injectionToken) return;
    attempts += 1;

    const menu = findOpenNativeMenuForRow(row);
    if (menu && injectNativeMenuItem(menu)) {
      return;
    }

    if (attempts < 20) {
      window.setTimeout(tick, 25);
    } else {
      resetActiveMenuState();
    }
  };

  window.setTimeout(tick, 0);
};

export async function load(lpl) {
  currentLpl = lpl;
  inviteInFlight = false;

  const { values } = lpl.settings.register({
    fields: [
      {
        type: 'toggle',
        key: 'includeMobileFriends',
        label: 'Include mobile friends',
        description: 'Attempt invites for friends who are online through League or Riot Mobile presence.',
        default: true,
      },
    ],
  });

  settingsState = {
    ...settingsState,
    ...values,
  };

  lpl.settings.onChange((key, value, nextValues) => {
    settingsState = {
      ...settingsState,
      ...nextValues,
    };
    lpl.log.info(`setting ${key} changed to ${value}`);
  });

  lpl.dom.addStyle(`
    .menu-item.${NATIVE_ITEM_CLASS} {
      text-transform: none;
    }
    .lpl-group-inviter-toasts {
      position: fixed;
      right: 20px;
      bottom: 24px;
      z-index: 2147483647;
      display: grid;
      gap: 10px;
      pointer-events: none;
    }
    .lpl-group-inviter-toast {
      min-width: 240px;
      max-width: 360px;
      padding: 12px 14px;
      border: 1px solid rgba(198, 160, 80, 0.28);
      background: rgba(15, 13, 11, 0.96);
      color: rgb(233, 223, 201);
      font-family: "LoL Body", "LoL Display", sans-serif;
      font-size: 12px;
      line-height: 1.45;
      box-shadow: 0 16px 34px rgba(0, 0, 0, 0.44);
      opacity: 0;
      transform: translateY(8px);
      transition: opacity 160ms ease, transform 160ms ease;
    }
    .lpl-group-inviter-toast.is-visible {
      opacity: 1;
      transform: translateY(0);
    }
    .lpl-group-inviter-toast.success {
      border-color: rgba(116, 198, 158, 0.34);
    }
    .lpl-group-inviter-toast.warn {
      border-color: rgba(213, 169, 84, 0.34);
    }
    .lpl-group-inviter-toast.error {
      border-color: rgba(191, 95, 95, 0.34);
    }
  `);

  const onContextMenu = (event) => {
    const target = event.target instanceof Element ? event.target : null;
    const row = target?.closest('.lol-social-roster-group');
    if (!row || !isVisibleElement(row)) {
      resetActiveMenuState();
      return;
    }

    const folderName = extractFolderName(row);
    if (!folderName) {
      resetActiveMenuState();
      return;
    }

    activeFolderName = folderName;
    activeRow = row;
    scheduleNativeMenuInjection(row);
  };

  const onPointerDown = (event) => {
    const target = event.target instanceof Element ? event.target : null;
    if (target?.closest('.lol-social-roster-group')) return;
    if (target?.closest(NATIVE_MENU_SELECTOR)) return;
    resetActiveMenuState();
  };

  const onWindowBlur = () => {
    resetActiveMenuState();
  };

  document.addEventListener('contextmenu', onContextMenu, true);
  document.addEventListener('pointerdown', onPointerDown, true);
  window.addEventListener('blur', onWindowBlur);

  lpl.log.info('group inviter armed');

  return () => {
    document.removeEventListener('contextmenu', onContextMenu, true);
    document.removeEventListener('pointerdown', onPointerDown, true);
    window.removeEventListener('blur', onWindowBlur);

    toastTimers.forEach((timer) => window.clearTimeout(timer));
    toastTimers = [];

    if (activeMenu) {
      const root = getNativeMenuRoot(activeMenu);
      if (root && activeMenu.__lplGroupInviterCloseListener) {
        root.removeEventListener('closeContextMenu', activeMenu.__lplGroupInviterCloseListener);
      }
      delete activeMenu.__lplGroupInviterCloseListener;
    }

    toastRoot?.remove();
    toastRoot = null;
    resetActiveMenuState();
    currentLpl = null;
    inviteInFlight = false;
  };
}
